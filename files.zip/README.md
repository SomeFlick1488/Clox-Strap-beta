# CloxStraper

Space-style Roblox launcher: Launch (with friends list) · Accounts (password-locked) · Modifications · Presets · Roblox Editor · FFlag Editor · Scripts (optional) · Shortcuts · Settings.
Languages: English, Українська, Русский. Default theme: Crimson. Default font: Comic Sans MS.

## Build
1. Install Python 3.10+ (tick "Add to PATH").
2. Run `build.bat`.
3. Installer: `dist\CloxStraper-Setup.exe` -> installs to `C:\Program Files\CloxStraper`.

Data lives in `%LOCALAPPDATA%\CloxStraper`. Cookies are encrypted with Windows DPAPI; the Accounts password is stored only as a salted PBKDF2 hash. Passwords for Roblox logins are never saved.

Not affiliated with Roblox Corporation. Use at your own risk.
