import io, math, os, sys, threading, time, webbrowser
import tkinter as tk
from tkinter import filedialog, font as tkfont
import customtkinter as ctk
from PIL import Image, ImageDraw, ImageFont, ImageTk
import engine as E
import sound
from i18n import T, set_lang, LANG_NAMES
from common import *

ctk.set_appearance_mode("dark")
SB = 220
NAV_ALL = [("Launch", "🚀"), ("Accounts", "👤"), ("Modifications", "🎨"), ("Presets", "📦"), ("Roblox Editor", "⚙"),
           ("FFlag Editor", "🚩"), ("Scripts", "📜"), ("Shortcuts", "⭐"), ("Settings", "🛠")]
NAV_STEP = 46
FONTS = ["Comic Sans MS", "Segoe UI", "Consolas", "Arial", "Verdana", "Trebuchet MS", "Georgia", "Tahoma", "Calibri", "Courier New"]
CLICKY = (ctk.CTkButton, ctk.CTkSwitch, ctk.CTkSegmentedButton, ctk.CTkOptionMenu, ctk.CTkCheckBox)


def circ(img, size):
    im = img.resize((size, size), Image.LANCZOS)
    m = Image.new("L", (size * 3, size * 3), 0); ImageDraw.Draw(m).ellipse((0, 0, size * 3 - 1, size * 3 - 1), fill=255)
    im.putalpha(m.resize((size, size), Image.LANCZOS))
    return ctk.CTkImage(im, size=(size, size))


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.cfg = E.load_cfg()
        apply_theme(self.cfg["theme"]); set_font(self.cfg["font"]); set_lang(self.cfg["lang"])
        ANIM["style"] = self.cfg["anim_style"]; ANIM["speed"] = self.cfg["anim_speed"]; sound.SOUND["on"] = self.cfg["sound"]
        self.title("CloxStraper"); self.geometry("1120x760"); self.minsize(1000, 700)
        self.attributes("-alpha", 0.0)
        self.sc = max(1.0, self.winfo_fpixels("1i") / 96)
        self.W, self.H = int(1120 * self.sc), int(760 * self.sc)
        self.t = 0.0; self.fx = []; self.avpil = {}; self.gpil = {}; self.hdr = {}; self.hooks = {}
        self.page_name = None; self.cur = "Launch"; self.launching = False; self.toasts = 0
        self.save_job = None; self.intro = None; self.acc_unlocked = False
        self.friends = []; self.fr_busy = False; self.fr_last = 0.0
        self.sb_loaded = False; self.sb_busy = False; self.sb_page = 1; self.sb_pages = 1; self.sb_query = ""
        self.found = None; self.found_t = -99.0
        self.build()
        self.fade_in(); self.tick()
        self.after(300, self.set_icon)
        self.bind_all("<ButtonPress-1>", self.on_click, add="+")
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        if not self.cfg["first_run_done"]: self.after(350, self.show_intro)

    # ------------------------------------------------------------ utils
    def on_close(self): self.destroy()
    def save(self): E.save_cfg(self.cfg)
    def save_soon(self):
        if self.save_job: self.after_cancel(self.save_job)
        self.save_job = self.after(400, self.save)

    def ui(self, fn):
        def run():
            try: fn()
            except tk.TclError: pass
        self.after(0, run)

    def on_click(self, e):
        w = e.widget
        for _ in range(5):
            if isinstance(w, CLICKY): sound.play("click"); return
            w = getattr(w, "master", None)
            if w is None: return

    def fade_in(self, a=0.0):
        a += 0.05; self.attributes("-alpha", min(a, 1))
        if a < 1: self.after(16, lambda: self.fade_in(a))

    def set_icon(self):
        try: self._ico = ImageTk.PhotoImage(make_planet(64, C.accent, C.accent2)); self.iconphoto(True, self._ico)
        except Exception: pass

    def navlist(self): return [n for n in NAV_ALL if n[0] != "Scripts" or self.cfg["scripts_tab"]]

    def paste_into(self, entry):
        try: text = self.clipboard_get().strip()
        except tk.TclError: return
        try:
            if entry._entry.selection_present(): entry.delete("sel.first", "sel.last")
        except tk.TclError: pass
        entry.insert("insert", text)

    def enable_paste(self, entry):
        inner = entry._entry
        def on_key(e):
            if e.keycode == 86: self.paste_into(entry)
            elif e.keycode in (67, 88):
                try:
                    self.clipboard_clear(); self.clipboard_append(inner.selection_get())
                    if e.keycode == 88: entry.delete("sel.first", "sel.last")
                except tk.TclError: pass
            elif e.keycode == 65: inner.select_range(0, "end"); inner.icursor("end")
            else: return
            return "break"
        inner.bind("<Control-KeyPress>", on_key)
        menu = tk.Menu(self, tearoff=0, bg=C.card2, fg=C.text, activebackground=C.accent, bd=0)
        menu.add_command(label=T("Paste"), command=lambda: self.paste_into(entry))
        menu.add_command(label=T("Clear"), command=lambda: entry.delete(0, "end"))
        inner.bind("<Button-3>", lambda e: menu.tk_popup(e.x_root, e.y_root))

    def entry(self, parent, **kw):
        e = ctk.CTkEntry(parent, height=kw.pop("height", 40), corner_radius=12, fg_color=C.bg, border_color=C.card2, font=F(13), **kw)
        self.enable_paste(e); return e

    def btn(self, parent, text, cmd, color=None, hover=None, tc=None, **kw):
        b = ctk.CTkButton(parent, text=text, command=cmd, height=kw.pop("height", 40), corner_radius=12, font=F(13, True),
                          fg_color=color or C.accent, hover_color=hover or C.accent2, **kw)
        if tc: b.configure(text_color=tc)
        return b

    def pick_file(self, types): return filedialog.askopenfilename(filetypes=types)

    # ------------------------------------------------------------ toast
    def toast(self, text, kind="info"):
        col = {"info": C.accent, "ok": C.accent2, "err": RED}[kind]
        if kind in ("ok", "err"): sound.play(kind)
        f = ctk.CTkFrame(self, fg_color=C.card2, corner_radius=14, border_width=2, border_color=col)
        ctk.CTkLabel(f, text=text, font=F(13, True), text_color=C.text, wraplength=320, justify="left").pack(padx=18, pady=12)
        y = -20 - self.toasts * 64; self.toasts += 1
        f.place(relx=1, rely=1, x=320, y=y, anchor="se"); f.lift()
        tween(self, 450, lambda e: f.place(relx=1, rely=1, x=-20 + 340 * (1 - e), y=y, anchor="se"))
        def out():
            tween(self, 350, lambda e: f.place(relx=1, rely=1, x=-20 + 340 * e, y=y, anchor="se"),
                  lambda: (f.destroy(), setattr(self, "toasts", max(0, self.toasts - 1))), ease=lin)
        self.after(3600, out)

    # ------------------------------------------------------------ build / layout
    def build(self):
        for w in self.winfo_children():
            if w is not self.intro: w.destroy()
        self.fx = [sf for sf in self.fx if getattr(sf, "keep", False)]
        self.hdr = {}; self.hooks = {}; self.pages = {}; self.page_name = None
        self.configure(fg_color=C.bg)
        self.cv = tk.Canvas(self, bg=C.bg, highlightthickness=0, bd=0); self.cv.place(x=0, y=0, relwidth=1, relheight=1)
        self.cv.bind("<Configure>", self.on_cfg)
        self.bg_sf = StarField(self.cv, n=110, orbs=True, shoot=self.cfg["shooting"]); self.fx.append(self.bg_sf)
        self.bg_sf.set_enabled(self.cfg["stars"])
        self.build_sidebar()
        builders = {"Launch": self.build_launch, "Accounts": self.build_accounts, "Modifications": self.build_mods, "Presets": self.build_presets,
                    "Roblox Editor": self.build_editor, "FFlag Editor": self.build_fflags, "Scripts": self.build_scripts,
                    "Shortcuts": self.build_shortcuts, "Settings": self.build_settings}
        for name, _ in self.navlist(): self.pages[name] = builders[name]()
        if self.cur not in self.pages: self.cur = "Launch"
        self.show(self.cur, animate=False)
        if self.intro: self.intro.lift()

    def on_cfg(self, e):
        self.W, self.H = e.width, e.height; self.bg_sf.resize(e.width, e.height)
        if self.page_name: self.pages[self.page_name].place(**self.geo())

    def geo(self, dx=0.0, dy=0.0):
        W, H, sc = max(self.W, 1), max(self.H, 1), self.sc
        x0 = (SB + 16) * sc
        return dict(relx=x0 / W + dx, rely=16 * sc / H + dy, relwidth=1 - (x0 + 16 * sc) / W, relheight=1 - 32 * sc / H)

    def build_sidebar(self):
        s = self.side = ctk.CTkFrame(self, width=SB, corner_radius=0, fg_color=C.side); s.place(x=0, y=0, relheight=1)
        self.logo_img = ctk.CTkImage(make_planet(120, C.accent, C.accent2), size=(70, 70))
        ctk.CTkLabel(s, text="", image=self.logo_img).place(x=14, y=10)
        row = ctk.CTkFrame(s, fg_color="transparent"); row.place(x=14, y=82)
        self.logo1 = ctk.CTkLabel(row, text="Clox", font=F(24, True), text_color=C.accent); self.logo1.pack(side="left")
        self.logo2 = ctk.CTkLabel(row, text="Straper", font=F(24, True), text_color=C.text); self.logo2.pack(side="left")
        ctk.CTkLabel(s, text="ROBLOX LAUNCHER", font=F(10, True), text_color=C.muted).place(x=16, y=116)
        self.nav = {}
        for i, (name, icon) in enumerate(self.navlist()):
            b = ctk.CTkButton(s, text=f"  {icon}   {T(name)}", width=SB - 28, height=40, corner_radius=12, anchor="w", fg_color=C.side,
                              hover=False, text_color=C.muted, font=F(13, True), command=lambda n=name: self.show(n))
            b.place(x=14, y=150 + i * NAV_STEP)
            b.bind("<Enter>", lambda e, n=name: self.nav_hover(n, True), add="+")
            b.bind("<Leave>", lambda e, n=name: self.nav_hover(n, False), add="+")
            self.nav[name] = b
        self.ind = ctk.CTkFrame(s, width=4, height=24, corner_radius=2, fg_color=C.accent); self.ind.place(x=4, y=158); self.ind_y = 158.0
        self.status_dot = ctk.CTkLabel(s, text="●", font=F(12), text_color=C.muted); self.status_dot.place(x=16, rely=1, y=-30, anchor="sw")
        ctk.CTkLabel(s, text=f"v{E.VERSION}", font=F(11), text_color=C.muted).place(x=36, rely=1, y=-30, anchor="sw")

    def nav_base(self, name): return blend(C.side, C.accent, 0.2) if name == self.page_name else C.side

    def nav_hover(self, name, on):
        b = self.nav.get(name)
        if not b: return
        a = self.nav_base(name); z = blend(a, C.card2, 0.9) if name != self.page_name else blend(a, C.accent, 0.35)
        c0, c1 = (a, z) if on else (z, a)
        tween(self, 160, lambda e: b.configure(fg_color=blend(c0, c1, e)), ease=lin)

    def move_indicator(self, idx):
        y0 = self.ind_y; y1 = 158 + idx * NAV_STEP
        tween(self, 450, lambda e: self.ind.place(x=4, y=y0 + (y1 - y0) * e)); self.ind_y = float(y1)

    # ------------------------------------------------------------ page switching
    def show(self, name, animate=True):
        if name == self.page_name: return
        names = [n for n, _ in self.navlist()]
        if self.page_name == "Accounts": self.acc_unlocked = False
        old = self.pages.get(self.page_name) if self.page_name else None
        oi = names.index(self.page_name) if self.page_name in names else 0; ni = names.index(name); d = 1 if ni >= oi else -1
        self.page_name = name; self.cur = name; new = self.pages[name]
        for n, b in self.nav.items(): b.configure(text_color=C.text if n == name else C.muted, fg_color=self.nav_base(n))
        self.move_indicator(ni); new.place(**self.geo(0, 0.07 * d)); new.lift()
        if old is None or not animate:
            for p in self.pages.values():
                if p is not new: p.place_forget()
            new.place(**self.geo()); self.page_enter(name); return
        sound.play("whoosh")
        def step(e): new.place(**self.geo(0, 0.07 * d * (1 - e))); old.place(**self.geo(0, -0.07 * d * e))
        def done():
            if self.page_name != name or old is new: return
            old.place_forget()
        tween(self, 480, step, done); self.page_enter(name)

    def page_enter(self, name):
        h = self.hdr.get(name)
        if h:
            t, title, bar = h
            tween(self, 420, lambda e: (t.configure(text=title[:max(1, int(len(title) * min(1, e)))]), bar.configure(width=max(4, int(90 * min(1.0, e))))), ease=lin)
        if self.hooks.get(name): self.hooks[name]()

    def page_frame(self, key, title, sub):
        title, sub = T(title), T(sub)
        p = ctk.CTkFrame(self, fg_color=C.card, corner_radius=24)
        head = ctk.CTkFrame(p, fg_color="transparent"); head.pack(fill="x", padx=28, pady=(20, 4))
        t = ctk.CTkLabel(head, text=title, font=F(27, True), text_color=C.text); t.pack(anchor="w")
        bar = ctk.CTkFrame(head, height=4, width=90, corner_radius=2, fg_color=C.accent); bar.pack(anchor="w", pady=(4, 4))
        ctk.CTkLabel(head, text=sub, font=F(13), text_color=C.muted).pack(anchor="w")
        body = ctk.CTkFrame(p, fg_color="transparent"); body.pack(fill="both", expand=True, padx=24, pady=(6, 18))
        self.hdr[key] = (t, title, bar); return p, body

    def scroll(self, parent):
        s = ctk.CTkScrollableFrame(parent, fg_color=C.card, corner_radius=0, scrollbar_button_color=C.card2, scrollbar_button_hover_color=C.accent)
        s.pack(fill="both", expand=True); return s

    def section(self, parent, title, desc=None):
        f = ctk.CTkFrame(parent, fg_color=C.card2, corner_radius=18); f.pack(fill="x", pady=8, padx=4)
        ctk.CTkLabel(f, text=T(title), font=F(16, True), text_color=C.text).pack(anchor="w", padx=18, pady=(14, 0 if desc else 8))
        if desc: ctk.CTkLabel(f, text=T(desc), font=F(12), text_color=C.muted, wraplength=640, justify="left").pack(anchor="w", padx=18, pady=(2, 8))
        return f

    def switch_row(self, parent, label, value, cb):
        row = ctk.CTkFrame(parent, fg_color="transparent"); row.pack(fill="x", padx=18, pady=5)
        ctk.CTkLabel(row, text=T(label), font=F(13), text_color=C.text).pack(side="left")
        var = tk.BooleanVar(value=bool(value))
        ctk.CTkSwitch(row, text="", variable=var, width=46, progress_color=C.accent, command=lambda: cb(var.get())).pack(side="right")
        return row

    def warn_box(self, parent, title, text, color):
        box = ctk.CTkFrame(parent, fg_color=blend(C.card, RED, 0.13), corner_radius=14, border_width=2, border_color=color); box.pack(fill="x", pady=(0, 10))
        lbl = ctk.CTkLabel(box, text=T(title), font=F(19, True), text_color=color); lbl.pack(pady=(10, 0))
        ctk.CTkLabel(box, text=T(text), font=F(12), text_color=C.muted, wraplength=700, justify="center").pack(pady=(2, 10), padx=14)
        return box, lbl

    # ------------------------------------------------------------ tick
    def roblox_found(self):
        if self.t - self.found_t > 3: self.found = bool(E.player_exe()); self.found_t = self.t
        return self.found

    def tick(self):
        self.t += 0.033; t = self.t
        try:
            if self.cfg["parallax"]:
                mx = (self.winfo_pointerx() - self.winfo_rootx()) / max(1, self.winfo_width())
                my = (self.winfo_pointery() - self.winfo_rooty()) / max(1, self.winfo_height())
                mouse = (min(1, max(0, mx)), min(1, max(0, my)))
            else: mouse = (0.5, 0.5)
            for sf in list(self.fx):
                if sf.alive(): sf.step(0.033, mouse, self.cfg["shooting"])
                else: self.fx.remove(sf)
            k = (math.sin(t * 1.4) + 1) / 2
            self.logo1.configure(text_color=blend(C.accent, C.accent2, k)); self.logo2.configure(text_color=blend(C.text, C.accent, 1 - k * 0.6))
            self.status_dot.configure(text_color=blend(C.muted, C.accent2, 0.5 + 0.5 * math.sin(t * 3)) if self.roblox_found() else RED)
            if self.page_name == "Launch":
                self.launch_anim()
                if time.time() - self.fr_last > 45 and not self.fr_busy: self.fr_refresh()
            if self.page_name == "FFlag Editor":
                self.ff_warn.configure(border_color=blend(C.warn, RED, (math.sin(t * 4) + 1) / 2)); self.ff_warn_lbl.configure(text_color=blend(C.warn, "#ffffff", (math.sin(t * 4 + 1) + 1) / 5))
            if self.page_name == "Scripts":
                self.sw_box.configure(border_color=blend(RED, "#ffffff", (math.sin(t * 5) + 1) / 3)); self.sw_lbl.configure(text_color=blend(RED, "#ffffff", (math.sin(t * 5 + 1) + 1) / 4))
        except (tk.TclError, AttributeError): pass
        self.after(33, self.tick)

    # ============================================================ LAUNCH
    def build_launch(self):
        p = ctk.CTkFrame(self, fg_color=C.card, corner_radius=24)
        fp = ctk.CTkFrame(p, fg_color=C.card2, corner_radius=18, height=215); fp.pack(side="bottom", fill="x", padx=14, pady=(0, 14)); fp.pack_propagate(False)
        head = ctk.CTkFrame(fp, fg_color="transparent"); head.pack(fill="x", padx=16, pady=(10, 0))
        self.fr_title = ctk.CTkLabel(head, text=T("👥  Friends playing"), font=F(14, True), text_color=C.text); self.fr_title.pack(side="left")
        self.btn(head, "⟳", self.fr_refresh, C.card, C.accent, width=36, height=28).pack(side="right")
        self.fr_list = ctk.CTkScrollableFrame(fp, fg_color=C.card2, corner_radius=0, scrollbar_button_color=C.card, scrollbar_button_hover_color=C.accent)
        self.fr_list.pack(fill="both", expand=True, padx=6, pady=(2, 8))
        cv = self.lcv = tk.Canvas(p, bg=C.card, highlightthickness=0, bd=0); cv.pack(fill="both", expand=True, padx=10, pady=(10, 4))
        self.l_sf = StarField(cv, n=70, orbs=True, shoot=True, bg=C.card); self.fx.append(self.l_sf); self.l_sf.set_enabled(self.cfg["stars"])
        self.l_glow = [cv.create_oval(0, 0, 1, 1, outline="", fill=C.card) for _ in range(4)]
        self.planet_ph = ImageTk.PhotoImage(make_planet(int(230 * self.sc), C.accent, C.accent2))
        self.l_planet = cv.create_image(0, 0, image=self.planet_ph)
        self.l_title = cv.create_text(0, 0, text=T("Ready for launch"), fill=C.text, font=F(26, True))
        self.l_acc = cv.create_text(0, 0, text="", fill=C.muted, font=F(13))
        self.l_log = cv.create_text(0, 0, text="", fill=C.accent2, font=F(12))
        self.l_chips = cv.create_text(0, 0, text="", fill=C.muted, font=F(11))
        self.l_entry = self.entry(cv, width=420, placeholder_text=T("Game link or Place ID (optional)"))
        if self.cfg["last_game"]: self.l_entry.insert(0, self.cfg["last_game"])
        self.l_entry.bind("<KeyRelease>", lambda e: self.fr_show(self.friends))
        self.l_btn = ctk.CTkButton(cv, text=T("LAUNCH ROBLOX"), width=340, height=60, corner_radius=30, font=F(18, True), fg_color=C.accent,
                                   hover_color=C.accent2, bg_color=C.card, command=self.launch_click)
        self.l_install = ctk.CTkButton(cv, text=T("⬇  Install Roblox"), width=180, height=34, corner_radius=17, font=F(12, True), fg_color=C.card2,
                                       hover_color=C.accent, bg_color=C.card, command=self.install_click)
        self.w_entry = cv.create_window(0, 0, window=self.l_entry); self.w_btn = cv.create_window(0, 0, window=self.l_btn)
        self.w_inst = cv.create_window(0, 0, window=self.l_install, state="hidden")
        cv.bind("<Configure>", self.lay_launch); self.hooks["Launch"] = self.launch_enter
        return p

    def lay_launch(self, e):
        w, h = e.width, e.height; cv = self.lcv; self.l_sf.resize(w, h); self.lw, self.lh = w, h
        cv.coords(self.l_title, w / 2, h * 0.08); cv.coords(self.l_acc, w / 2, h * 0.53); cv.coords(self.w_entry, w / 2, h * 0.64)
        cv.coords(self.w_btn, w / 2, h * 0.80); cv.coords(self.l_log, w / 2, h * 0.92); cv.coords(self.l_chips, w / 2, h * 0.975)
        cv.coords(self.w_inst, w - 110, h * 0.08)

    def launch_anim(self):
        if not hasattr(self, "lw"): return
        w, h, t, cv = self.lw, self.lh, self.t, self.lcv
        cv.coords(self.l_planet, w / 2, h * 0.31 + 7 * math.sin(t * 1.3))
        bx, by = w / 2, h * 0.80; k = (math.sin(t * 2.2) + 1) / 2; busy = 1.0 if self.launching else 0.0
        for i, it in enumerate(self.l_glow):
            r = (200 + i * 26 + 10 * k * (1 + busy * 2)) * (1.0 if w > 600 else 0.7); ry = 42 + i * 13 + 6 * k
            cv.coords(it, bx - r * 0.5, by - ry, bx + r * 0.5, by + ry)
            cv.itemconfigure(it, fill=blend(C.card, C.accent, (0.14 - i * 0.03) * (0.6 + 0.4 * k + busy * 0.5)))
        cv.tag_lower(self.l_glow[0]); [cv.tag_raise(g, self.l_glow[0]) for g in self.l_glow[1:]]; cv.tag_lower("fx")

    def launch_enter(self):
        self.refresh_status(); self.fr_refresh()

    def refresh_status(self):
        acc = E.active_account(self.cfg)
        self.lcv.itemconfigure(self.l_acc, text=T("Playing as  {name}  (@{user})").format(name=acc["display"], user=acc["name"]) if acc else T("Guest mode — no account (add one in Accounts)"),
                               fill=C.accent2 if acc else C.muted)
        ver = E.newest_version(); nfl = len(E.build_flags(self.cfg)); m = self.cfg["mods"]; nm = sum(bool(m[k]) for k in ("cursor_on", "font_on", "sky_on"))
        self.lcv.itemconfigure(self.l_chips, text=T("Roblox: {ver}     •     {n} FFlags     •     {m} mods").format(ver=os.path.basename(ver) if ver else T("not found"), n=nfl, m=nm))
        self.lcv.itemconfigure(self.w_inst, state="hidden" if ver else "normal")

    def set_log(self, t): self.lcv.itemconfigure(self.l_log, text=t)

    def ripple(self):
        w, h = self.lw, self.lh; cv = self.lcv; bx, by = w / 2, h * 0.80
        for i in range(3):
            it = cv.create_oval(bx, by, bx, by, outline=C.accent2, width=3)
            def go(it=it):
                tween(self, 900, lambda e: (cv.coords(it, bx - 40 - 260 * e, by - 30 - 130 * e, bx + 40 + 260 * e, by + 30 + 130 * e),
                                            cv.itemconfigure(it, outline=blend(C.accent2, C.card, e))), lambda: cv.delete(it), ease=out_cubic)
            self.after(i * 140, go)

    def launch_click(self):
        txt = self.l_entry.get().strip(); pid = E.parse_place(txt) if txt else None
        if txt and not pid: self.toast(T("Couldn't read that game link / Place ID"), "err"); return
        self.cfg["last_game"] = txt; self.save(); self.launch_place(pid)

    def launch_place(self, pid, job=None):
        if self.launching: return
        self.show("Launch"); self.launching = True; self.ripple(); self.l_btn.configure(text=T("LAUNCHING…"), state="disabled")
        def log(t): self.ui(lambda: self.set_log(t))
        def work():
            try: E.launch_game(self.cfg, pid, log, job); self.ui(self.launch_done)
            except Exception as e:
                msg = str(e); self.ui(lambda: self.launch_fail(msg))
        threading.Thread(target=work, daemon=True).start()

    def launch_done(self):
        self.launching = False; self.l_btn.configure(text=T("LAUNCH ROBLOX"), state="normal")
        self.set_log(T("Roblox is starting…")); self.toast(T("Roblox is starting! 🚀"), "ok")
        if self.cfg["close_after_launch"]: self.after(3000, self.on_close)

    def launch_fail(self, msg):
        self.launching = False; self.l_btn.configure(text=T("LAUNCH ROBLOX"), state="normal"); self.set_log(""); self.toast(msg, "err"); self.refresh_status()

    def install_click(self):
        self.l_install.configure(state="disabled", text=T("Downloading…"))
        def work():
            try: E.install_roblox(lambda t: self.ui(lambda: self.set_log(t))); self.ui(lambda: self.toast(T("Roblox installer started"), "ok"))
            except Exception as e:
                m = str(e); self.ui(lambda: self.toast(m, "err"))
            self.ui(lambda: self.l_install.configure(state="normal", text=T("⬇  Install Roblox")))
        threading.Thread(target=work, daemon=True).start()

    # ---- друзья
    def fr_refresh(self):
        acc = E.active_account(self.cfg)
        if not acc: self.friends = []; self.fr_show([], T("Log in to see which friends are playing")); return
        if self.fr_busy: return
        self.fr_busy = True; self.fr_last = time.time(); self.fr_show(None, T("Loading friends…"))
        def work():
            try:
                data = E.friends_in_game(E.unprotect(acc["cookie"]), acc["id"]); self.ui(lambda: self.fr_done(data, None))
            except Exception as e: self.ui(lambda: self.fr_done(None, T("Couldn't load friends")))
        threading.Thread(target=work, daemon=True).start()

    def fr_done(self, data, err):
        self.fr_busy = False
        if data is not None: self.friends = data
        self.fr_show(self.friends, err)

    def fr_show(self, data, msg=None):
        for w in self.fr_list.winfo_children(): w.destroy()
        if data is None or msg:
            ctk.CTkLabel(self.fr_list, text=msg or "", font=F(12), text_color=C.muted).pack(pady=18); return
        txt = self.l_entry.get().strip(); pid = E.parse_place(txt) if txt else None
        rows = [f for f in data if not pid or f["place"] == pid]
        self.fr_title.configure(text=T("👥  Friends in this game") + f"  ({len(rows)})" if pid else T("👥  Friends playing") + f"  ({len(rows)})")
        if not rows:
            ctk.CTkLabel(self.fr_list, text=T("No friends are in this game right now") if pid else T("None of your friends are playing right now"),
                         font=F(12), text_color=C.muted).pack(pady=18); return
        for f in rows:
            row = ctk.CTkFrame(self.fr_list, fg_color=C.card, corner_radius=12); row.pack(fill="x", pady=3, padx=4)
            av = ctk.CTkLabel(row, text="👤" if not f["img"] else "", width=40, height=40, font=F(16), image=circ(f["img"], 40) if f["img"] else None); av.pack(side="left", padx=8, pady=5)
            info = ctk.CTkFrame(row, fg_color="transparent"); info.pack(side="left")
            ctk.CTkLabel(info, text=f["display"], font=F(13, True), text_color=C.text).pack(anchor="w")
            ctk.CTkLabel(info, text=(f["loc"] or "")[:44], font=F(11), text_color=C.muted).pack(anchor="w")
            if f["place"] and f["job"]:
                self.btn(row, T("▶  Join"), lambda f=f: self.launch_place(f["place"], f["job"]), width=90, height=30).pack(side="right", padx=10)

    # ============================================================ ACCOUNTS
    def build_accounts(self):
        p, body = self.page_frame("Accounts", "Accounts", "Log in with a cookie or a username & password")
        top = ctk.CTkFrame(body, fg_color="transparent"); top.pack(fill="x", pady=(0, 10))
        self.acc_seg = ctk.CTkSegmentedButton(top, values=[T("Cookie"), T("Username & Password")], command=self.acc_switch, selected_color=C.accent,
                                              selected_hover_color=C.accent2, unselected_color=C.card2, fg_color=C.card2, font=F(13, True))
        self.acc_seg.pack(side="left"); self.acc_seg.set(T("Cookie"))
        self.btn(top, T("🔑 Change password"), lambda: self.acc_lock_show("change"), C.card2, C.accent, width=170).pack(side="right")
        holder = ctk.CTkFrame(body, fg_color=C.card2, corner_radius=16); holder.pack(fill="x")
        self.ck_form = ctk.CTkFrame(holder, fg_color="transparent")
        r = ctk.CTkFrame(self.ck_form, fg_color="transparent"); r.pack(fill="x", padx=16, pady=(16, 6))
        self.ck_entry = self.entry(r, show="•", placeholder_text="_|WARNING:-DO-NOT-SHARE-THIS..."); self.ck_entry.pack(side="left", fill="x", expand=True)
        self.ck_entry.bind("<Return>", lambda e: self.add_cookie())
        self.btn(r, T("📋 Paste"), lambda: self.paste_into(self.ck_entry), C.card, C.accent, width=90).pack(side="left", padx=(8, 0))
        self.ck_btn = self.btn(self.ck_form, T("It's me!  ➜"), self.add_cookie, width=200, height=44); self.ck_btn.pack(anchor="w", padx=16, pady=(4, 6))
        ctk.CTkLabel(self.ck_form, text=T("Stored encrypted with Windows DPAPI on this PC only. Never share your cookie."), font=F(11), text_color=C.muted).pack(anchor="w", padx=16, pady=(0, 14))
        self.pw_form = ctk.CTkFrame(holder, fg_color="transparent")
        r2 = ctk.CTkFrame(self.pw_form, fg_color="transparent"); r2.pack(fill="x", padx=16, pady=(16, 6))
        self.pw_user = self.entry(r2, placeholder_text=T("Username")); self.pw_user.pack(side="left", fill="x", expand=True)
        self.pw_pass = self.entry(r2, show="•", placeholder_text=T("Password")); self.pw_pass.pack(side="left", fill="x", expand=True, padx=(8, 0))
        self.pw_pass.bind("<Return>", lambda e: self.add_password())
        self.pw_btn = self.btn(self.pw_form, T("Log in  ➜"), self.add_password, width=200, height=44); self.pw_btn.pack(anchor="w", padx=16, pady=(4, 6))
        ctk.CTkLabel(self.pw_form, text=T("Password is never saved. If Roblox asks for captcha / 2-step verification, use the Cookie method."), font=F(11), text_color=C.muted).pack(anchor="w", padx=16, pady=(0, 14))
        self.ck_form.pack(fill="x")
        ctk.CTkLabel(body, text=T("Your accounts"), font=F(15, True), text_color=C.text).pack(anchor="w", pady=(14, 4))
        self.acc_list = self.scroll(body)
        self.acc_lock = ctk.CTkFrame(p, fg_color=C.card, corner_radius=24)
        self.hooks["Accounts"] = self.acc_enter
        return p

    def acc_switch(self, v):
        self.ck_form.pack_forget(); self.pw_form.pack_forget()
        (self.ck_form if v == T("Cookie") else self.pw_form).pack(fill="x")

    # ---- замок на вкладке
    def acc_enter(self):
        self.refresh_accounts()
        if not self.acc_unlocked: self.acc_lock_show("create" if not self.cfg.get("acc_pass") else "unlock")

    def acc_lock_show(self, mode):
        lk = self.acc_lock
        for w in lk.winfo_children(): w.destroy()
        lk.place(relx=0, rely=0, relwidth=1, relheight=1); lk.lift()
        box = ctk.CTkFrame(lk, fg_color=C.card2, corner_radius=22, width=440, height=360 if mode != "unlock" else 330, border_width=2, border_color=C.accent)
        box.place(relx=0.5, rely=0.5, anchor="center"); box.pack_propagate(False)
        ctk.CTkLabel(box, text="🔒", font=F(40)).pack(pady=(20, 0))
        titles = {"create": "Create accounts password", "unlock": "Accounts are locked", "change": "Change password"}
        subs = {"create": "It will be asked every time you open this tab.", "unlock": "Enter your password to continue.", "change": "Choose a new password."}
        ctk.CTkLabel(box, text=T(titles[mode]), font=F(19, True), text_color=C.text).pack(pady=(4, 0))
        ctk.CTkLabel(box, text=T(subs[mode]), font=F(12), text_color=C.muted).pack(pady=(0, 10))
        e1 = self.entry(box, show="•", width=300, placeholder_text=T("Password") if mode == "unlock" else T("New password")); e1.pack(pady=4)
        e2 = None
        if mode != "unlock": e2 = self.entry(box, show="•", width=300, placeholder_text=T("Repeat password")); e2.pack(pady=4)
        msg = ctk.CTkLabel(box, text="", font=F(12), text_color=RED); msg.pack(pady=2)
        def shake(i=0):
            dx = int(math.sin(i * 1.6) * (14 - i)) if i < 14 else 0
            box.place(relx=0.5, rely=0.5, anchor="center", x=dx)
            if i < 14: self.after(22, lambda: shake(i + 1))
        def fail(t): msg.configure(text=t); sound.play("err"); shake()
        def unlock():
            self.acc_unlocked = True; sound.play("ok")
            tween(self, 450, lambda e: lk.place(relx=0, rely=-e, relwidth=1, relheight=1), lk.place_forget, ease=out_cubic)
        def submit():
            if mode == "unlock":
                if E.check_password(self.cfg, e1.get()): unlock()
                else: fail(T("Wrong password"))
            else:
                a, b = e1.get(), e2.get()
                if len(a) < 4: fail(T("At least 4 characters")); return
                if a != b: fail(T("Passwords don't match")); return
                E.set_password(self.cfg, a); self.save(); unlock(); self.toast(T("Password saved"), "ok")
        if e2: e2.bind("<Return>", lambda e: submit()); e1.bind("<Return>", lambda e: e2.focus_set())
        else: e1.bind("<Return>", lambda e: submit())
        self.btn(box, T("Unlock") if mode == "unlock" else T("Save password"), submit, width=300, height=44).pack(pady=(6, 4))
        if mode == "change": self.btn(box, T("Cancel"), lambda: tween(self, 350, lambda e: lk.place(relx=0, rely=-e, relwidth=1, relheight=1), lk.place_forget), C.card, C.accent, width=300, height=34).pack()
        if mode == "unlock":
            armed = {"v": False}
            def forgot():
                if not armed["v"]:
                    armed["v"] = True; fb.configure(text=T("Click again: this DELETES all saved accounts"), text_color=RED); return
                self.cfg["accounts"] = []; self.cfg["active"] = None; self.cfg["acc_pass"] = None; self.save(); self.refresh_accounts(); self.acc_lock_show("create")
            fb = ctk.CTkButton(box, text=T("Forgot password?"), command=forgot, fg_color="transparent", hover=False, text_color=C.muted, font=F(11), height=24); fb.pack()
        e1.focus_set()

    # ---- добавление аккаунта
    def add_cookie(self):
        c = self.ck_entry.get().strip()
        if not c: self.toast(T("Paste your .ROBLOSECURITY first"), "err"); return
        self.ck_btn.configure(state="disabled", text=T("Checking…"))
        def work():
            try: r = E.Roblox(c); r.login(); av = r.avatar(); self.ui(lambda: self.account_added(r, c, av))
            except Exception as e:
                m = str(e) if isinstance(e, RuntimeError) else T("No connection to Roblox"); self.ui(lambda: self.account_failed(m))
        threading.Thread(target=work, daemon=True).start()

    def add_password(self):
        u, pw = self.pw_user.get().strip(), self.pw_pass.get()
        if not u or not pw: self.toast(T("Enter username and password"), "err"); return
        self.pw_btn.configure(state="disabled", text=T("Logging in…"))
        def work():
            try: ck = E.login_password(u, pw); r = E.Roblox(ck); r.login(); av = r.avatar(); self.ui(lambda: self.account_added(r, ck, av))
            except Exception as e:
                m = str(e) if isinstance(e, RuntimeError) else T("No connection to Roblox"); self.ui(lambda: self.account_failed(m))
        threading.Thread(target=work, daemon=True).start()

    def account_failed(self, msg):
        self.ck_btn.configure(state="normal", text=T("It's me!  ➜")); self.pw_btn.configure(state="normal", text=T("Log in  ➜")); self.toast(msg, "err")

    def store_account(self, r, cookie, av):
        accs = [a for a in self.cfg["accounts"] if a["id"] != r.uid]
        accs.append(dict(id=r.uid, name=r.name, display=r.display, cookie=E.protect(cookie)))
        self.cfg["accounts"] = accs; self.cfg["active"] = r.uid; self.save()
        if av: self.avpil[r.uid] = av

    def account_added(self, r, cookie, av):
        self.ck_btn.configure(state="normal", text=T("It's me!  ➜")); self.pw_btn.configure(state="normal", text=T("Log in  ➜"))
        self.ck_entry.delete(0, "end"); self.pw_pass.delete(0, "end"); self.store_account(r, cookie, av)
        self.toast(T("Welcome, {name}! ✨").format(name=r.display), "ok"); self.refresh_accounts()

    def refresh_accounts(self):
        for w in self.acc_list.winfo_children(): w.destroy()
        if not self.cfg["accounts"]:
            ctk.CTkLabel(self.acc_list, text=T("No accounts yet — add one above.\nYou can also play as guest from the Launch tab."), font=F(13), text_color=C.muted).pack(pady=30)
        for i, a in enumerate(self.cfg["accounts"]):
            active = a["id"] == self.cfg.get("active")
            row = ctk.CTkFrame(self.acc_list, fg_color=C.card2, corner_radius=16, border_width=2, border_color=C.accent2 if active else C.card2); row.pack(fill="x", pady=5, padx=2)
            av = ctk.CTkLabel(row, text="👤", width=52, height=52, font=F(22)); av.pack(side="left", padx=12, pady=10)
            if a["id"] in self.avpil: av.configure(image=circ(self.avpil[a["id"]], 52), text="")
            else: self.fetch_avatar(a["id"], av)
            info = ctk.CTkFrame(row, fg_color="transparent"); info.pack(side="left")
            ctk.CTkLabel(info, text=a["display"], font=F(15, True), text_color=C.text).pack(anchor="w")
            ctk.CTkLabel(info, text=f"@{a['name']}  •  ID {a['id']}", font=F(11), text_color=C.muted).pack(anchor="w")
            self.btn(row, "✕", lambda aid=a["id"]: self.remove_account(aid), C.card, RED, width=40).pack(side="right", padx=12)
            if active: ctk.CTkLabel(row, text=T("● ACTIVE"), font=F(12, True), text_color=C.accent2).pack(side="right", padx=8)
            else: self.btn(row, T("Set active"), lambda aid=a["id"]: self.set_active(aid), C.card, C.accent, width=110).pack(side="right", padx=4)
            tween(self, 500 + i * 120, lambda e, r=row, act=active: r.configure(border_color=blend(C.accent, C.accent2 if act else C.card2, e)), ease=lin)

    def fetch_avatar(self, uid, label):
        def work():
            try:
                acc = next(a for a in self.cfg["accounts"] if a["id"] == uid)
                r = E.Roblox(E.unprotect(acc["cookie"])); r.uid = uid; img = r.avatar()
                if img: self.avpil[uid] = img; self.ui(lambda: label.configure(image=circ(img, 52), text=""))
            except Exception: pass
        threading.Thread(target=work, daemon=True).start()

    def set_active(self, aid): self.cfg["active"] = aid; self.save(); self.refresh_accounts(); self.toast(T("Active account changed"), "ok")

    def remove_account(self, aid):
        self.cfg["accounts"] = [a for a in self.cfg["accounts"] if a["id"] != aid]
        if self.cfg.get("active") == aid: self.cfg["active"] = self.cfg["accounts"][0]["id"] if self.cfg["accounts"] else None
        self.save(); self.refresh_accounts(); self.toast(T("Account removed"))

    # ============================================================ MODIFICATIONS
    def build_mods(self):
        p, body = self.page_frame("Modifications", "Modifications", "Custom cursor, font and sky — applied on every launch")
        sc = self.scroll(body); m = self.cfg["mods"]
        def put(k, v): m[k] = v; self.save_soon()
        c = self.section(sc, "🖱  Custom cursor", "Your image replaces Roblox's arrow cursor (PNG with transparency works best).")
        self.switch_row(c, "Enable custom cursor", m["cursor_on"], lambda v: put("cursor_on", v))
        r = ctk.CTkFrame(c, fg_color="transparent"); r.pack(fill="x", padx=18, pady=(4, 14))
        self.cur_prev = ctk.CTkLabel(r, text=T("no image"), width=84, height=84, fg_color=C.bg, corner_radius=14, font=F(11), text_color=C.muted); self.cur_prev.pack(side="left")
        col = ctk.CTkFrame(r, fg_color="transparent"); col.pack(side="left", padx=14)
        self.btn(col, T("Choose image…"), self.pick_cursor, width=160).pack(anchor="w")
        sz = ctk.CTkFrame(col, fg_color="transparent"); sz.pack(anchor="w", pady=(8, 0))
        ctk.CTkLabel(sz, text=T("Size"), font=F(12), text_color=C.muted).pack(side="left")
        om = ctk.CTkOptionMenu(sz, values=["32", "48", "64", "96", "128"], width=80, fg_color=C.card, button_color=C.accent, button_hover_color=C.accent2, command=lambda v: put("cursor_size", int(v)))
        om.set(str(m["cursor_size"])); om.pack(side="left", padx=8); self.load_cursor_preview()
        f = self.section(sc, "🔤  Custom font", "Replaces all Roblox UI fonts with your .ttf / .otf font.")
        self.switch_row(f, "Enable custom font", m["font_on"], lambda v: put("font_on", v))
        r = ctk.CTkFrame(f, fg_color="transparent"); r.pack(fill="x", padx=18, pady=(4, 14))
        self.font_prev = ctk.CTkLabel(r, text=T("no font selected"), height=70, width=330, fg_color=C.bg, corner_radius=14, font=F(11), text_color=C.muted); self.font_prev.pack(side="left")
        self.btn(r, T("Choose font…"), self.pick_font, width=150).pack(side="left", padx=14); self.load_font_preview()
        s = self.section(sc, "🌌  Custom sky", "Generated skies — or use your own picture on all six faces.")
        self.switch_row(s, "Enable custom sky", m["sky_on"], lambda v: put("sky_on", v))
        r = ctk.CTkFrame(s, fg_color="transparent"); r.pack(fill="x", padx=18, pady=(4, 6))
        self.sky_menu = ctk.CTkOptionMenu(r, values=list(E.SKY_PRESETS) + ["Custom image"], width=170, fg_color=C.card, button_color=C.accent, button_hover_color=C.accent2, command=self.sky_change)
        self.sky_menu.set(m["sky_preset"]); self.sky_menu.pack(side="left")
        self.btn(r, T("🎲 Re-roll stars"), self.sky_reroll, C.card, C.accent, width=140).pack(side="left", padx=8)
        self.btn(r, T("Choose image…"), self.pick_sky, C.card, C.accent, width=140).pack(side="left")
        self.sky_prev = ctk.CTkLabel(s, text="", fg_color="transparent"); self.sky_prev.pack(anchor="w", padx=18, pady=(4, 14)); self.load_sky_preview()
        a = ctk.CTkFrame(sc, fg_color="transparent"); a.pack(fill="x", pady=10, padx=4)
        self.btn(a, T("✓  Apply now"), self.apply_now, width=170, height=44).pack(side="left")
        self.btn(a, T("↺  Restore Roblox defaults"), self.restore_defaults, C.card2, RED, width=240, height=44).pack(side="left", padx=10)
        return p

    def load_cursor_preview(self):
        pth = self.cfg["mods"]["cursor_path"]
        if pth and os.path.exists(pth):
            try: self.cur_prev.configure(image=ctk.CTkImage(Image.open(pth).convert("RGBA"), size=(64, 64)), text="")
            except Exception: pass

    def pick_cursor(self):
        f = self.pick_file([("Images", "*.png *.jpg *.jpeg *.gif *.bmp *.webp")])
        if f: self.cfg["mods"]["cursor_path"] = f; self.cfg["mods"]["cursor_on"] = True; self.save(); self.load_cursor_preview(); self.toast(T("Cursor selected"), "ok")

    def load_font_preview(self):
        pth = self.cfg["mods"]["font_path"]
        if pth and os.path.exists(pth):
            try:
                im = Image.new("RGBA", (330, 70), (0, 0, 0, 0)); ImageDraw.Draw(im).text((14, 16), "The quick brown fox 123", font=ImageFont.truetype(pth, 26), fill=C.text)
                self.font_prev.configure(image=ctk.CTkImage(im, size=(330, 70)), text="")
            except Exception: self.font_prev.configure(text=os.path.basename(pth), image=None)

    def pick_font(self):
        f = self.pick_file([("Fonts", "*.ttf *.otf")])
        if f: self.cfg["mods"]["font_path"] = f; self.cfg["mods"]["font_on"] = True; self.save(); self.load_font_preview(); self.toast(T("Font selected"), "ok")

    def load_sky_preview(self):
        m = self.cfg["mods"]
        try:
            imgs = E.make_sky(m["sky_preset"], m["sky_seed"], m["sky_custom"]); strip = Image.new("RGB", (3 * 170 + 20, 170))
            for i, f in enumerate(("lf", "ft", "up")): strip.paste(imgs[f].resize((170, 170)), (i * 180, 0))
            self.sky_prev.configure(image=ctk.CTkImage(strip, size=(550, 170)), text="")
        except Exception: pass

    def sky_change(self, v):
        self.cfg["mods"]["sky_preset"] = v; self.save()
        if v == "Custom image" and not self.cfg["mods"]["sky_custom"]: self.pick_sky()
        self.load_sky_preview()

    def sky_reroll(self): self.cfg["mods"]["sky_seed"] = int(time.time()) % 100000; self.save(); self.load_sky_preview()

    def pick_sky(self):
        f = self.pick_file([("Images", "*.png *.jpg *.jpeg *.bmp *.webp")])
        if f: self.cfg["mods"].update(sky_custom=f, sky_preset="Custom image", sky_on=True); self.sky_menu.set("Custom image"); self.save(); self.load_sky_preview()

    def apply_now(self):
        def work():
            try: E.apply_all(self.cfg); self.ui(lambda: self.toast(T("Applied to Roblox ✓"), "ok"))
            except Exception as e:
                m = str(e); self.ui(lambda: self.toast(m, "err"))
        threading.Thread(target=work, daemon=True).start()

    def restore_defaults(self):
        n = E.restore_all(); self.toast(T("Restored {n} original files").format(n=n) if n else T("Nothing to restore"), "ok" if n else "info")

    # ============================================================ PRESETS
    def build_presets(self):
        p, body = self.page_frame("Presets", "Presets", "One-click configs — or save your own")
        sv = ctk.CTkFrame(body, fg_color=C.card2, corner_radius=16); sv.pack(fill="x")
        r = ctk.CTkFrame(sv, fg_color="transparent"); r.pack(fill="x", padx=14, pady=14)
        self.pr_name = self.entry(r, placeholder_text=T("Name for your preset")); self.pr_name.pack(side="left", fill="x", expand=True)
        self.pr_name.bind("<Return>", lambda e: self.pr_save())
        self.btn(r, T("💾 Save current settings"), self.pr_save, width=220).pack(side="left", padx=(8, 0))
        self.pr_list = self.scroll(body); self.hooks["Presets"] = self.pr_refresh
        return p

    def pr_card(self, pr, custom, i):
        row = ctk.CTkFrame(self.pr_list, fg_color=C.card2, corner_radius=16, border_width=2, border_color=C.card2); row.pack(fill="x", pady=5, padx=2)
        ctk.CTkLabel(row, text=pr.get("icon", "📁"), width=54, height=54, font=F(26), fg_color=C.bg, corner_radius=14).pack(side="left", padx=12, pady=10)
        info = ctk.CTkFrame(row, fg_color="transparent"); info.pack(side="left", fill="x", expand=True)
        ctk.CTkLabel(info, text=pr["name"] if custom else T(pr["name"]), font=F(15, True), text_color=C.text).pack(anchor="w")
        desc = T("Your saved preset") if custom else T(pr["desc"])
        ctk.CTkLabel(info, text=desc, font=F(11), text_color=C.muted, wraplength=420, justify="left").pack(anchor="w")
        if custom: self.btn(row, "✕", lambda idx=i: self.pr_del(idx), C.card, RED, width=40).pack(side="right", padx=12)
        self.btn(row, T("Apply"), lambda: self.pr_apply(pr), width=100, height=42).pack(side="right", padx=4)
        tween(self, 500 + i * 110, lambda e, r=row: r.configure(border_color=blend(C.accent2, C.card2, e)), ease=lin)

    def pr_refresh(self):
        for w in self.pr_list.winfo_children(): w.destroy()
        ctk.CTkLabel(self.pr_list, text=T("Built-in"), font=F(14, True), text_color=C.accent2).pack(anchor="w", pady=(2, 0))
        for i, pr in enumerate(E.BUILTIN_PRESETS): self.pr_card(pr, False, i)
        ctk.CTkLabel(self.pr_list, text=T("My presets"), font=F(14, True), text_color=C.accent2).pack(anchor="w", pady=(10, 0))
        if not self.cfg["presets"]: ctk.CTkLabel(self.pr_list, text=T("Nothing saved yet — set up Roblox the way you like and press Save."), font=F(12), text_color=C.muted).pack(pady=10)
        for i, pr in enumerate(self.cfg["presets"]): self.pr_card(pr, True, i)

    def pr_save(self):
        name = self.pr_name.get().strip()
        if not name: self.toast(T("Give your preset a name"), "err"); return
        c = self.cfg; snap = dict(name=name, icon="⭐", theme=c["theme"], rbx=dict(c["rbx"]), fflags=dict(c["fflags"]), mods=dict(c["mods"]))
        c["presets"] = [p for p in c["presets"] if p["name"] != name] + [snap]; self.save(); self.pr_name.delete(0, "end"); self.pr_refresh()
        self.toast(T("Preset “{name}” saved").format(name=name), "ok")

    def pr_del(self, i): del self.cfg["presets"][i]; self.save(); self.pr_refresh()

    def pr_apply(self, pr):
        c = self.cfg
        if "rbx" in pr: c["rbx"] = dict(pr["rbx"])
        if "fflags" in pr: c["fflags"] = dict(pr["fflags"])
        if "mods" in pr: c["mods"].update(pr["mods"])
        if pr.get("doors_cursor"): c["mods"]["cursor_path"] = E.make_doors_cursor()
        if pr.get("theme"): c["theme"] = pr["theme"]; apply_theme(pr["theme"])
        self.save(); self.cur = "Presets"; self.build(); self.toast(T("Preset applied — it takes effect on next launch"), "ok")

    # ============================================================ ROBLOX EDITOR
    def build_editor(self):
        p, body = self.page_frame("Roblox Editor", "Roblox Editor", "Tweak Roblox itself — applied automatically when you launch")
        sc = self.scroll(body); sections = {}
        names = {"Graphics": "🎮  Graphics", "Interface": "🖥  Interface", "Audio": "🔊  Audio", "Input": "🖱  Input & Camera"}
        for s in E.SETTINGS:
            if s["section"] not in sections: sections[s["section"]] = self.section(sc, names[s["section"]])
            self.setting_row(sections[s["section"]], s)
        for sec in sections.values(): ctk.CTkFrame(sec, height=8, fg_color="transparent").pack()
        a = ctk.CTkFrame(sc, fg_color="transparent"); a.pack(fill="x", pady=10, padx=4)
        self.btn(a, T("✓  Apply now"), self.apply_now, width=170, height=44).pack(side="left")
        self.btn(a, T("↺  Reset all"), self.reset_editor, C.card2, RED, width=150, height=44).pack(side="left", padx=10)
        ctk.CTkLabel(a, text=T("Close Roblox before applying.  Only changed settings are written."), font=F(11), text_color=C.muted).pack(side="left", padx=8)
        return p

    def setting_row(self, parent, s):
        key, r = s["key"], self.cfg["rbx"]; cur = r.get(key, s["default"])
        row = ctk.CTkFrame(parent, fg_color="transparent"); row.pack(fill="x", padx=18, pady=5)
        ctk.CTkLabel(row, text=T(s["label"]), font=F(13), text_color=C.text).pack(side="left")
        def put(v): r[key] = v; self.save_soon()
        if s["kind"] == "switch":
            var = tk.BooleanVar(value=bool(cur)); ctk.CTkSwitch(row, text="", variable=var, width=46, progress_color=C.accent, command=lambda: put(var.get())).pack(side="right")
        elif s["kind"] == "slider":
            fmt = s.get("fmt", "{:.0f}"); isf = isinstance(s["default"], float)
            lbl = ctk.CTkLabel(row, text=fmt.format(cur), width=56, font=F(13, True), text_color=C.accent2); lbl.pack(side="right")
            def cmd(v):
                v = round(v, 1) if isf else int(round(v)); lbl.configure(text=fmt.format(v)); put(v)
            sl = ctk.CTkSlider(row, from_=s["lo"], to=s["hi"], number_of_steps=int(round((s["hi"] - s["lo"]) / s["step"])), width=240, progress_color=C.accent,
                               button_color=C.accent2, button_hover_color="#ffffff", command=cmd); sl.set(cur); sl.pack(side="right", padx=10)
        else:
            om = ctk.CTkOptionMenu(row, values=s["opts"], width=170, fg_color=C.card, button_color=C.accent, button_hover_color=C.accent2, command=put); om.set(cur); om.pack(side="right")

    def reset_editor(self):
        self.cfg["rbx"] = {}; self.save(); self.cur = "Roblox Editor"; self.build(); self.toast(T("Roblox Editor reset"), "ok")

    # ============================================================ FFLAG EDITOR
    def build_fflags(self):
        p, body = self.page_frame("FFlag Editor", "FFlag Editor", "Fast Flags — hidden Roblox engine switches")
        self.ff_warn, self.ff_warn_lbl = self.warn_box(body, "⚠  WARNING you can break your game!", "Wrong flags can crash Roblox or be silently ignored. Only change what you understand.", C.warn)
        bar = ctk.CTkFrame(body, fg_color="transparent"); bar.pack(fill="x", pady=(0, 8))
        self.ff_search = self.entry(bar, width=200, placeholder_text=T("🔍 Search flags…")); self.ff_search.pack(side="left"); self.ff_search.bind("<KeyRelease>", lambda e: self.ff_filter())
        self.btn(bar, T("＋ Add"), lambda: self.ff_add_row("", ""), width=80).pack(side="left", padx=6)
        pm = ctk.CTkOptionMenu(bar, values=list(E.PRESETS), width=160, fg_color=C.card2, button_color=C.accent, button_hover_color=C.accent2, command=self.ff_preset); pm.set(T("Quick add…")); pm.pack(side="left")
        self.btn(bar, T("Import"), self.ff_import, C.card2, C.accent, width=80).pack(side="left", padx=6)
        self.btn(bar, T("Export"), self.ff_export, C.card2, C.accent, width=80).pack(side="left")
        self.btn(bar, T("💾 Save"), self.ff_save, C.accent2, "#ffffff", "#06281e", width=100).pack(side="right")
        self.btn(bar, T("Clear"), self.ff_clear, C.card2, RED, width=70).pack(side="right", padx=6)
        self.ff_list = self.scroll(body); self.ff_rows = []
        for k, v in self.cfg["fflags"].items(): self.ff_add_row(k, E.fmt_flag_value(v))
        return p

    def ff_add_row(self, name, val):
        nv, vv = tk.StringVar(value=name), tk.StringVar(value=val)
        row = ctk.CTkFrame(self.ff_list, fg_color=C.card2, corner_radius=12); row.pack(fill="x", pady=3, padx=2)
        ne = ctk.CTkEntry(row, textvariable=nv, width=380, height=36, corner_radius=10, fg_color=C.bg, border_color=C.card2, font=F(12), placeholder_text="FlagName"); ne.pack(side="left", padx=(10, 6), pady=7); self.enable_paste(ne)
        ve = ctk.CTkEntry(row, textvariable=vv, width=150, height=36, corner_radius=10, fg_color=C.bg, border_color=C.card2, font=F(12), placeholder_text="value"); ve.pack(side="left", padx=6); self.enable_paste(ve)
        rec = dict(row=row, nv=nv, vv=vv); self.btn(row, "✕", lambda r=rec: self.ff_del(r), C.card, RED, width=36, height=36).pack(side="right", padx=10); self.ff_rows.append(rec)
        tween(self, 450, lambda e: row.configure(fg_color=blend(C.accent, C.card2, e)), ease=lin)

    def ff_del(self, rec): rec["row"].destroy(); self.ff_rows.remove(rec)

    def ff_filter(self):
        q = self.ff_search.get().strip().lower()
        for r in self.ff_rows:
            r["row"].pack_forget()
            if q in r["nv"].get().lower(): r["row"].pack(fill="x", pady=3, padx=2)

    def ff_collect(self): return {r["nv"].get().strip(): E.parse_flag_value(r["vv"].get()) for r in self.ff_rows if r["nv"].get().strip()}
    def ff_save(self): self.cfg["fflags"] = self.ff_collect(); self.save(); self.toast(T("Saved {n} flags").format(n=len(self.cfg["fflags"])), "ok")
    def ff_clear(self):
        for r in list(self.ff_rows): self.ff_del(r)

    def ff_preset(self, name):
        have = {r["nv"].get() for r in self.ff_rows}
        for k, v in E.PRESETS[name].items():
            if k not in have: self.ff_add_row(k, E.fmt_flag_value(v))
        self.toast(T("Added “{name}” — press Save").format(name=name))

    def ff_import(self):
        import json
        f = self.pick_file([("JSON", "*.json")])
        if not f: return
        try:
            with open(f, encoding="utf-8") as fh: d = json.load(fh)
            for k, v in d.items(): self.ff_add_row(k, v if isinstance(v, str) else E.fmt_flag_value(v))
            self.toast(T("Imported {n} flags — press Save").format(n=len(d)))
        except Exception as e: self.toast(str(e), "err")

    def ff_export(self):
        import json
        f = filedialog.asksaveasfilename(defaultextension=".json", initialfile="ClientAppSettings.json", filetypes=[("JSON", "*.json")])
        if f:
            with open(f, "w", encoding="utf-8") as fh: json.dump({k: E.fmt_flag_value(v) for k, v in self.ff_collect().items()}, fh, indent=2)
            self.toast(T("Exported"), "ok")

    # ============================================================ SCRIPTS (ScriptBlox)
    def build_scripts(self):
        p, body = self.page_frame("Scripts", "Scripts", "Public scripts from ScriptBlox — view & copy only")
        self.sw_box, self.sw_lbl = self.warn_box(body, "⚠  WARNING cheats are bad!",
            "Cheating breaks Roblox's rules, ruins the game for other players and can get your account banned. Scripts from the internet can also hide malware that steals your account. CloxStraper only shows and copies code — it never runs it.", RED)
        bar = ctk.CTkFrame(body, fg_color="transparent"); bar.pack(fill="x", pady=(0, 8))
        self.sb_q = self.entry(bar, placeholder_text=T("🔍 Search ScriptBlox…")); self.sb_q.pack(side="left", fill="x", expand=True); self.sb_q.bind("<Return>", lambda e: self.sb_search())
        self.btn(bar, T("Search"), self.sb_search, width=90).pack(side="left", padx=6)
        self.btn(bar, "◀", lambda: self.sb_go(-1), C.card2, C.accent, width=40).pack(side="left")
        self.sb_lbl = ctk.CTkLabel(bar, text="1 / 1", width=70, font=F(12, True), text_color=C.muted); self.sb_lbl.pack(side="left")
        self.btn(bar, "▶", lambda: self.sb_go(1), C.card2, C.accent, width=40).pack(side="left")
        self.sb_list = self.scroll(body); self.sb_loaded = False
        self.hooks["Scripts"] = lambda: None if self.sb_loaded else self.sb_load()
        return p

    def sb_search(self): self.sb_query = self.sb_q.get().strip(); self.sb_load(1)
    def sb_go(self, d):
        n = self.sb_page + d
        if 1 <= n <= self.sb_pages: self.sb_load(n)

    def sb_load(self, page=1):
        if self.sb_busy: return
        self.sb_busy = True; self.sb_loaded = True
        for w in self.sb_list.winfo_children(): w.destroy()
        ctk.CTkLabel(self.sb_list, text=T("Loading scripts…"), font=F(13), text_color=C.muted).pack(pady=30)
        q = self.sb_query
        def work():
            try: items, pages = E.scriptblox(q, page); self.ui(lambda: self.sb_show(items, page, pages, None))
            except Exception: self.ui(lambda: self.sb_show([], page, 1, T("Couldn't reach ScriptBlox")))
        threading.Thread(target=work, daemon=True).start()

    def sb_show(self, items, page, pages, err):
        self.sb_busy = False; self.sb_page, self.sb_pages = page, pages; self.sb_lbl.configure(text=f"{page} / {pages}")
        for w in self.sb_list.winfo_children(): w.destroy()
        if err or not items:
            ctk.CTkLabel(self.sb_list, text=err or T("No scripts found"), font=F(13), text_color=RED if err else C.muted).pack(pady=30)
            if err: self.sb_loaded = False
            return
        for i, s in enumerate(items):
            row = ctk.CTkFrame(self.sb_list, fg_color=C.card2, corner_radius=14, border_width=2, border_color=C.card2); row.pack(fill="x", pady=4, padx=2)
            info = ctk.CTkFrame(row, fg_color="transparent"); info.pack(side="left", fill="x", expand=True, padx=14, pady=8)
            ctk.CTkLabel(info, text=s["title"][:70], font=F(14, True), text_color=C.text, anchor="w").pack(anchor="w")
            badges = ("✔ " + T("verified") + "  " if s["verified"] else "") + ("🔑 " + T("key") + "  " if s["key"] else "") + ("⚠ " + T("patched") + "  " if s["patched"] else "")
            ctk.CTkLabel(info, text=f"{s['game'][:40]}  •  👁 {s['views']}   {badges}", font=F(11), text_color=C.muted, anchor="w").pack(anchor="w")
            self.btn(row, T("Open"), lambda sl=s["slug"]: webbrowser.open(f"https://scriptblox.com/script/{sl}"), C.card, C.accent, width=70, height=34).pack(side="right", padx=(4, 12))
            self.btn(row, T("Copy"), lambda sc=s: self.sb_copy(sc), width=70, height=34).pack(side="right", padx=4)
            tween(self, 400 + i * 40, lambda e, r=row: r.configure(border_color=blend(C.accent, C.card2, e)), ease=lin)

    def sb_copy(self, s):
        if not s["code"]: self.toast(T("No code in the listing — use Open"), "err"); return
        self.clipboard_clear(); self.clipboard_append(s["code"]); self.update()
        self.toast(T("Copied. Remember: cheating can get you banned."), "info")

    # ============================================================ SHORTCUTS
    def build_shortcuts(self):
        p, body = self.page_frame("Shortcuts", "Shortcuts", "Save a game link — jump in with one click ✦")
        add = ctk.CTkFrame(body, fg_color=C.card2, corner_radius=16); add.pack(fill="x")
        r = ctk.CTkFrame(add, fg_color="transparent"); r.pack(fill="x", padx=14, pady=14)
        self.sc_name = self.entry(r, width=170, placeholder_text=T("Name (optional)")); self.sc_name.pack(side="left")
        self.sc_link = self.entry(r, placeholder_text=T("Game link or Place ID")); self.sc_link.pack(side="left", fill="x", expand=True, padx=8); self.sc_link.bind("<Return>", lambda e: self.sc_add())
        self.sc_btn = self.btn(r, T("＋ Add shortcut"), self.sc_add, width=150); self.sc_btn.pack(side="left")
        self.sc_list = self.scroll(body); self.hooks["Shortcuts"] = self.sc_refresh
        return p

    def sc_add(self):
        pid = E.parse_place(self.sc_link.get())
        if not pid: self.toast(T("Couldn't read that game link / Place ID"), "err"); return
        name = self.sc_name.get().strip(); self.sc_btn.configure(state="disabled", text=T("Adding…"))
        def work():
            n, img = E.game_info(pid); self.ui(lambda: self.sc_added(pid, name or n or f"Place {pid}", img))
        threading.Thread(target=work, daemon=True).start()

    def sc_added(self, pid, name, img):
        self.sc_btn.configure(state="normal", text=T("＋ Add shortcut")); self.cfg["shortcuts"].append(dict(name=name, pid=pid)); self.save()
        if img: self.gpil[pid] = img
        self.sc_name.delete(0, "end"); self.sc_link.delete(0, "end"); self.sc_refresh(); self.toast(T("Shortcut “{name}” added").format(name=name), "ok")

    def sc_refresh(self):
        for w in self.sc_list.winfo_children(): w.destroy()
        if not self.cfg["shortcuts"]: ctk.CTkLabel(self.sc_list, text=T("✦  No shortcuts yet.\nPaste a game link above to create your first one."), font=F(13), text_color=C.muted).pack(pady=40)
        for i, s in enumerate(self.cfg["shortcuts"]):
            row = ctk.CTkFrame(self.sc_list, fg_color=C.card2, corner_radius=16, border_width=2, border_color=C.card2); row.pack(fill="x", pady=5, padx=2)
            ic = ctk.CTkLabel(row, text="🪐", width=60, height=60, font=F(26), fg_color=C.bg, corner_radius=14); ic.pack(side="left", padx=12, pady=10)
            if s["pid"] in self.gpil: ic.configure(image=ctk.CTkImage(self.gpil[s["pid"]], size=(60, 60)), text="")
            else: self.sc_icon(s["pid"], ic)
            info = ctk.CTkFrame(row, fg_color="transparent"); info.pack(side="left")
            ctk.CTkLabel(info, text=s["name"], font=F(15, True), text_color=C.text).pack(anchor="w")
            ctk.CTkLabel(info, text=f"Place ID {s['pid']}", font=F(11), text_color=C.muted).pack(anchor="w")
            self.btn(row, "✕", lambda idx=i: self.sc_del(idx), C.card, RED, width=40).pack(side="right", padx=12)
            self.btn(row, T("▶  Join"), lambda pid=s["pid"]: self.launch_place(pid), width=110, height=42).pack(side="right", padx=4)
            self.after(i * 110, lambda r=row: tween(self, 700, lambda e: r.configure(border_color=blend(C.accent2, C.card2, e)), ease=lin))

    def sc_icon(self, pid, label):
        def work():
            n, img = E.game_info(pid)
            if img: self.gpil[pid] = img; self.ui(lambda: label.configure(image=ctk.CTkImage(img, size=(60, 60)), text=""))
        threading.Thread(target=work, daemon=True).start()

    def sc_del(self, idx): del self.cfg["shortcuts"][idx]; self.save(); self.sc_refresh()

    # ============================================================ SETTINGS
    def build_settings(self):
        p, body = self.page_frame("Settings", "Settings", "Make CloxStraper yours")
        sc = self.scroll(body); c = self.cfg
        a = self.section(sc, "🎨  Appearance", "Theme, font and language change instantly.")
        r = ctk.CTkFrame(a, fg_color="transparent"); r.pack(fill="x", padx=18, pady=(2, 8))
        ctk.CTkLabel(r, text=T("Client theme"), font=F(13), text_color=C.text).pack(side="left")
        sw = ctk.CTkFrame(r, fg_color="transparent"); sw.pack(side="right")
        for name, th in THEMES.items():
            ctk.CTkButton(sw, text="", width=32, height=32, corner_radius=16, fg_color=th["accent"], hover_color=th["accent2"], border_width=3,
                          border_color="#ffffff" if name == c["theme"] else C.card2, command=lambda n=name: self.set_theme(n)).pack(side="left", padx=3)
        r = ctk.CTkFrame(a, fg_color="transparent"); r.pack(fill="x", padx=18, pady=(2, 8))
        ctk.CTkLabel(r, text=T("Font"), font=F(13), text_color=C.text).pack(side="left")
        fams = set(tkfont.families()); opts = [f for f in FONTS if f in fams] or ["Comic Sans MS"]
        if c["font"] not in opts: opts.append(c["font"])
        om = ctk.CTkOptionMenu(r, values=opts, width=200, fg_color=C.card, button_color=C.accent, button_hover_color=C.accent2, command=self.set_font_cfg); om.set(c["font"]); om.pack(side="right")
        r = ctk.CTkFrame(a, fg_color="transparent"); r.pack(fill="x", padx=18, pady=(2, 14))
        ctk.CTkLabel(r, text=T("Language"), font=F(13), text_color=C.text).pack(side="left")
        lo = ctk.CTkOptionMenu(r, values=list(LANG_NAMES.values()), width=200, fg_color=C.card, button_color=C.accent, button_hover_color=C.accent2, command=self.set_language)
        lo.set(LANG_NAMES[c["lang"]]); lo.pack(side="right")
        b = self.section(sc, "✨  Animations & sound")
        r = ctk.CTkFrame(b, fg_color="transparent"); r.pack(fill="x", padx=18, pady=5)
        ctk.CTkLabel(r, text=T("Animation type"), font=F(13), text_color=C.text).pack(side="left")
        seg = ctk.CTkSegmentedButton(r, values=list(EASES), selected_color=C.accent, selected_hover_color=C.accent2, unselected_color=C.card, fg_color=C.card, command=self.set_anim); seg.set(c["anim_style"]); seg.pack(side="right")
        r = ctk.CTkFrame(b, fg_color="transparent"); r.pack(fill="x", padx=18, pady=5)
        ctk.CTkLabel(r, text=T("Animation speed"), font=F(13), text_color=C.text).pack(side="left")
        lbl = ctk.CTkLabel(r, text=f"{c['anim_speed']:.1f}x", width=50, font=F(13, True), text_color=C.accent2); lbl.pack(side="right")
        def spd(v): v = round(v, 1); lbl.configure(text=f"{v:.1f}x"); ANIM["speed"] = v; c["anim_speed"] = v; self.save_soon()
        sl = ctk.CTkSlider(r, from_=0.5, to=2.5, number_of_steps=20, width=240, progress_color=C.accent, button_color=C.accent2, command=spd); sl.set(c["anim_speed"]); sl.pack(side="right", padx=10)
        def tog(key, cb=None):
            def f(v): c[key] = v; self.save(); cb and cb(v)
            return f
        self.switch_row(b, "Click sounds", c["sound"], tog("sound", lambda v: (sound.SOUND.update(on=v), sound.play("click"))))
        self.switch_row(b, "Starfield background", c["stars"], tog("stars", lambda v: (self.bg_sf.set_enabled(v), self.l_sf.set_enabled(v))))
        self.switch_row(b, "Shooting stars", c["shooting"], tog("shooting"))
        self.switch_row(b, "Mouse parallax", c["parallax"], tog("parallax"))
        ctk.CTkFrame(b, height=8, fg_color="transparent").pack()
        d = self.section(sc, "🚀  Launcher")
        self.switch_row(d, "Show the Scripts tab", c["scripts_tab"], self.set_scripts_tab)
        self.switch_row(d, "Close CloxStraper after launching Roblox", c["close_after_launch"], tog("close_after_launch"))
        r = ctk.CTkFrame(d, fg_color="transparent"); r.pack(fill="x", padx=18, pady=(6, 4))
        self.btn(r, T("Use as Roblox launcher"), self.reg_proto, width=210).pack(side="left"); self.btn(r, T("Restore original"), self.unreg_proto, C.card, RED, width=160).pack(side="left", padx=8)
        ctk.CTkLabel(d, text=T("“Use as Roblox launcher”: Play buttons on roblox.com start Roblox through CloxStraper (so your FFlags & mods always apply). Roblox updates may undo this."),
                     font=F(11), text_color=C.muted, wraplength=640, justify="left").pack(anchor="w", padx=18, pady=(2, 8))
        r = ctk.CTkFrame(d, fg_color="transparent"); r.pack(fill="x", padx=18, pady=(0, 14))
        self.btn(r, T("📁 Open data folder"), lambda: os.startfile(E.DATA) if E.IS_WIN else None, C.card, C.accent, width=190).pack(side="left")
        self.btn(r, T("Show setup again"), lambda: self.show_intro(), C.card, C.accent, width=170).pack(side="left", padx=8)
        e = self.section(sc, f"CloxStraper {E.VERSION}", "Not affiliated with Roblox Corporation. Use at your own risk — modifying the client may break after Roblox updates."); ctk.CTkFrame(e, height=6, fg_color="transparent").pack()
        return p

    def rebuild_to(self, page): self.cur = page; self.build()
    def set_theme(self, name): self.cfg["theme"] = name; self.save(); apply_theme(name); self.rebuild_to("Settings"); self.toast(f"{T('Client theme')}: {name}", "ok")
    def set_font_cfg(self, fam): self.cfg["font"] = fam; self.save(); set_font(fam); self.rebuild_to("Settings"); self.toast(f"{T('Font')}: {fam}", "ok")
    def set_anim(self, v): self.cfg["anim_style"] = v; ANIM["style"] = v; self.save(); self.toast(f"{T('Animation type')}: {v}", "ok")
    def set_scripts_tab(self, v): self.cfg["scripts_tab"] = v; self.save(); self.rebuild_to("Settings")

    def set_language(self, display):
        code = next(k for k, v in LANG_NAMES.items() if v == display); self.cfg["lang"] = code; self.save(); set_lang(code); self.rebuild_to("Settings")

    def exe_path(self): return sys.executable if getattr(sys, "frozen", False) else os.path.abspath(__file__)

    def reg_proto(self):
        if not E.IS_WIN: self.toast("Windows only", "err"); return
        try:
            exe = self.exe_path()
            if not getattr(sys, "frozen", False): exe = f'{sys.executable}" "{exe}'
            E.register_protocol(self.cfg, exe); self.save(); self.toast(T("CloxStraper is now your Roblox launcher ✓"), "ok")
        except Exception as e: self.toast(str(e), "err")

    def unreg_proto(self):
        if not E.IS_WIN: return
        try: E.unregister_protocol(self.cfg); self.save(); self.toast(T("Original launcher restored"), "ok")
        except Exception as e: self.toast(str(e), "err")

    # ============================================================ SETUP WIZARD («подготовка»)
    def show_intro(self):
        if self.intro: return
        self.cfg["first_run_done"] = True; self.save()
        ov = self.intro = ctk.CTkFrame(self, fg_color=C.bg, corner_radius=0); ov.place(relx=0, rely=0, relwidth=1, relheight=1); ov.lift()
        cv = self.wcv = tk.Canvas(ov, bg=C.bg, highlightthickness=0, bd=0); cv.pack(fill="both", expand=True)
        sf = StarField(cv, n=170, orbs=True, shoot=True); sf.keep = True; self.fx.append(sf)
        st = self.wst = dict(w=800, h=600, py=-300, items=[], step=-1, name=None)
        self._wph = ImageTk.PhotoImage(make_planet(int(280 * self.sc), C.accent, C.accent2))
        self.w_planet = cv.create_image(0, -400, image=self._wph)
        self.w_title = cv.create_text(0, 0, text="", fill=C.text, font=F(32, True)); self.w_sub = cv.create_text(0, 0, text="", fill=C.muted, font=F(14), width=760, justify="center")
        self.w_dots = [cv.create_oval(0, 0, 1, 1, fill=C.card2, outline="") for _ in range(5)]
        def lay(e=None):
            w, h = cv.winfo_width(), cv.winfo_height(); st["w"], st["h"] = w, h; sf.resize(w, h)
            cv.coords(self.w_title, w / 2, h * 0.55); cv.coords(self.w_sub, w / 2, h * 0.55 + 48)
            for i, d in enumerate(self.w_dots): x = w / 2 + (i - 2) * 26; cv.coords(d, x - 6, h - 34, x + 6, h - 22)
        cv.bind("<Configure>", lay)
        def float_planet():
            try: cv.coords(self.w_planet, st["w"] / 2, st["py"] + 8 * math.sin(self.t * 1.3)); self.after(33, float_planet)
            except tk.TclError: pass
        float_planet()
        def drop():
            y1 = max(cv.winfo_height(), 500) * 0.25
            tween(self, 1300, lambda e: st.__setitem__("py", lerp(-300, y1, e)), lambda: self.wiz_step(0))
        self.after(450, drop)

    def wput(self, widget, yfrac, xoff=0, delay=0):
        cv, st = self.wcv, self.wst; w, h = st["w"], st["h"]
        it = cv.create_window(w / 2 + xoff, h + 120, window=widget); st["items"].append((it, widget))
        self.after(delay, lambda: tween(self, 600, lambda e: cv.coords(it, w / 2 + xoff, lerp(h + 120, h * yfrac, e))))

    def wbtn(self, text, cmd, primary=True, w=220):
        return ctk.CTkButton(self.wcv, text=text, command=cmd, width=w, height=50, corner_radius=25, font=F(15, True), bg_color=C.bg,
                             fg_color=C.accent if primary else C.card2, hover_color=C.accent2 if primary else C.card)

    def wiz_msg(self, text, bad=False): self.wcv.itemconfigure(self.w_sub, text=text, fill=RED if bad else C.muted)

    def wiz_step(self, n):
        cv, st = self.wcv, self.wst
        for it, w in st["items"]: cv.delete(it); w.destroy()
        st["items"] = []; st["step"] = n
        for i, d in enumerate(self.w_dots): cv.itemconfigure(d, fill=C.accent2 if i == n else (C.accent if i < n else C.card2))
        titles = ["Welcome to CloxStraper", "Choose your language", "Protect your accounts", "Log in to Roblox", "You're all set!"]
        subs = ["Let's get everything ready — it only takes a minute ✦", "You can change it later in Settings.",
                "Set a password. It will be asked every time you open the Accounts tab.", "Paste your .ROBLOSECURITY cookie — or skip and add it later.", "CloxStraper is ready for launch 🚀"]
        title = T(titles[n])
        if n == 4 and st["name"]: title = T("Welcome, {name}! ✨").format(name=st["name"])
        cv.itemconfigure(self.w_title, text=""); cv.itemconfigure(self.w_sub, text="", fill=C.muted)
        self.type_c(cv, self.w_title, title, 40); self.after(300, lambda: self.type_c(cv, self.w_sub, T(subs[n]), 12))
        if n == 0: self.wput(self.wbtn(T("Start  ➜"), lambda: self.wiz_step(1)), 0.80, 0, 500)
        elif n == 1:
            for i, (code, name) in enumerate(LANG_NAMES.items()):
                self.wput(self.wbtn(name, lambda c=code: self.wiz_lang(c), True, 190), 0.76, (i - 1) * 205, 400 + i * 120)
        elif n == 2:
            e1 = self.entry(cv, show="•", width=320, placeholder_text=T("New password"), height=44); e2 = self.entry(cv, show="•", width=320, placeholder_text=T("Repeat password"), height=44)
            def go():
                a, b = e1.get(), e2.get()
                if len(a) < 4: self.wiz_msg(T("At least 4 characters"), True); sound.play("err"); return
                if a != b: self.wiz_msg(T("Passwords don't match"), True); sound.play("err"); return
                E.set_password(self.cfg, a); self.save(); sound.play("ok"); self.wiz_step(3)
            e2.bind("<Return>", lambda e: go()); self.wput(e1, 0.67, 0, 300); self.wput(e2, 0.74, 0, 400)
            self.wput(self.wbtn(T("Set password  ➜"), go, True, 200), 0.84, -110, 500); self.wput(self.wbtn(T("Later"), lambda: self.wiz_step(3), False, 200), 0.84, 110, 560)
        elif n == 3:
            ck = self.entry(cv, show="•", width=400, placeholder_text="_|WARNING:-DO-NOT-SHARE-THIS...", height=44)
            def go():
                c = ck.get().strip()
                if not c: self.wiz_msg(T("Paste your .ROBLOSECURITY first"), True); return
                self.wiz_msg(T("Checking…"))
                def work():
                    try:
                        r = E.Roblox(c); r.login(); av = r.avatar()
                        def ok(): self.store_account(r, c, av); st["name"] = r.display; sound.play("ok"); self.wiz_step(4)
                        self.ui(ok)
                    except Exception as e:
                        m = str(e) if isinstance(e, RuntimeError) else T("No connection to Roblox"); self.ui(lambda: (self.wiz_msg(m, True), sound.play("err")))
                threading.Thread(target=work, daemon=True).start()
            ck.bind("<Return>", lambda e: go()); self.wput(ck, 0.69, -50, 300)
            self.wput(self.wbtn("📋", lambda: self.paste_into(ck), False, 60), 0.69, 205, 360)
            self.wput(self.wbtn(T("It's me!  ➜"), go, True, 200), 0.80, -110, 450); self.wput(self.wbtn(T("Skip for now"), lambda: self.wiz_step(4), False, 200), 0.80, 110, 510)
        else: self.wput(self.wbtn(T("Let's go  ➜"), self.close_intro, True, 240), 0.80, 0, 500)

    def wiz_lang(self, code):
        self.cfg["lang"] = code; set_lang(code); self.save(); sound.play("pop"); self.wiz_step(2)

    def type_c(self, cv, item, text, delay=45, cb=None, i=0):
        try:
            cv.itemconfigure(item, text=text[:i])
            if i < len(text): self.after(delay, lambda: self.type_c(cv, item, text, delay, cb, i + 1))
            elif cb: cb()
        except tk.TclError: pass

    def close_intro(self):
        ov = self.intro
        if not ov: return
        self.cur = "Accounts" if False else "Launch"; self.build(); ov.lift()
        def done():
            try: ov.destroy()
            except tk.TclError: pass
            self.intro = None; self.fx = [sf for sf in self.fx if not getattr(sf, "keep", False)]
        tween(self, 700, lambda e: ov.place(relx=0, rely=-e, relwidth=1, relheight=1), done, ease=out_cubic)


def main():
    if len(sys.argv) > 1 and sys.argv[1].lower().startswith("roblox-player:"):
        try: E.handle_uri(E.load_cfg(), sys.argv[1])
        except Exception: pass
        return
    App().mainloop()


if __name__ == "__main__":
    main()
