"""Общее для лаунчера и установщика: темы, шрифты, анимации, звёздное небо, планета."""
import math, random, time, types
import tkinter as tk
from PIL import Image, ImageDraw, ImageFilter

THEMES = {
    "Nebula":  dict(bg="#070914", side="#0b0f24", card="#111633", card2="#1a2150", accent="#8b6cff", accent2="#38e8c6", warn="#ffb454"),
    "Aurora":  dict(bg="#050f0e", side="#09191a", card="#0e2423", card2="#153836", accent="#2ee6a6", accent2="#5ab8ff", warn="#ffb454"),
    "Sunset":  dict(bg="#130810", side="#1c0d1b", card="#2a1228", card2="#3d1a3b", accent="#ff6a88", accent2="#ffb454", warn="#ffd166"),
    "Ocean":   dict(bg="#050e1b", side="#0a182b", card="#0e2540", card2="#163a63", accent="#3aa0ff", accent2="#38e8c6", warn="#ffb454"),
    "Crimson": dict(bg="#10060a", side="#190a10", card="#260e17", card2="#3a1523", accent="#ff3b5c", accent2="#ff9a3c", warn="#ffd166"),
    "Doors":   dict(bg="#0a0705", side="#110a06", card="#1a100a", card2="#2b1a0f", accent="#d9a441", accent2="#b3261e", warn="#ffb454"),
    "Eclipse": dict(bg="#09090b", side="#101013", card="#17171c", card2="#24242c", accent="#e5e7eb", accent2="#8b92b8", warn="#ffb454"),
}
C = types.SimpleNamespace(text="#f2f4ff", muted="#8b92b8")
RED = "#ff6b81"
FONT = {"family": "Comic Sans MS"}
ANIM = {"style": "Smooth", "speed": 1.0}


def apply_theme(name):
    t = THEMES.get(name) or THEMES["Nebula"]
    C.__dict__.update(t); C.name = name

def set_font(family): FONT["family"] = family
def F(size, bold=False):
    return (FONT["family"], size, "bold") if bold else (FONT["family"], size)

apply_theme("Crimson")


def hex2rgb(h):
    h = h.lstrip("#"); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
def blend(a, b, t):
    t = max(0.0, min(1.0, t))
    return "#%02x%02x%02x" % tuple(int(x + (y - x) * t) for x, y in zip(hex2rgb(a), hex2rgb(b)))
def lerp(a, b, t): return a + (b - a) * t

def lin(t): return t
def out_cubic(t): return 1 - (1 - t) ** 3
def out_quint(t): return 1 - (1 - t) ** 5
def out_back(t):
    c = 1.70158; return 1 + (c + 1) * (t - 1) ** 3 + c * (t - 1) ** 2
def out_elastic(t):
    if t <= 0 or t >= 1: return t
    return 2 ** (-10 * t) * math.sin((t * 10 - 0.75) * (2 * math.pi / 3)) + 1
EASES = {"Smooth": out_cubic, "Bouncy": out_back, "Snappy": out_quint, "Elastic": out_elastic, "Off": lambda t: 1.0}


def tween(w, ms, fn, done=None, ease=None):
    """Плавная анимация: fn(e) вызывается ~60 раз/с, e идёт 0→1 (с учётом выбранного стиля)."""
    style = ANIM["style"]
    if style == "Off":
        try:
            fn(1.0)
            if done: done()
        except tk.TclError:
            pass
        return
    dur = ms / max(0.2, ANIM["speed"]); ez = ease or EASES.get(style, out_cubic); t0 = time.perf_counter()
    def step():
        p = min(1.0, (time.perf_counter() - t0) * 1000 / dur)
        try:
            fn(ez(p) if p < 1 else 1.0)
            if p < 1: w.after(16, step)
            elif done: done()
        except tk.TclError:
            pass
    step()


class StarField:
    """Звёзды (мерцание + параллакс), туманности и падающие звёзды на tk.Canvas."""
    def __init__(self, cv, n=90, orbs=True, shoot=True, bg=None):
        self.cv, self.n, self.orbs_on, self.shoot = cv, n, orbs, shoot
        self.bg = bg or C.bg
        self.W = self.H = 0; self.stars = []; self.orbs = []; self.sh = None; self.t = 0.0; self.enabled = True

    def alive(self):
        try: return bool(self.cv.winfo_exists())
        except tk.TclError: return False

    def resize(self, W, H):
        first = self.W == 0
        self.W, self.H = W, H
        if first: self.populate()

    def populate(self):
        cv = self.cv; cv.delete("fx"); self.stars = []; self.orbs = []
        if self.orbs_on:
            for col, f, ph in [(C.accent, (0.11, 0.15), 0), (C.accent2, (0.09, 0.17), 2), ("#ff5fa2", (0.07, 0.13), 4)]:
                rings = [cv.create_oval(0, 0, 1, 1, fill=blend(self.bg, col, 0.012 + 0.013 * k), outline="", tags="fx") for k in range(7)]
                self.orbs.append(dict(rings=rings, f=f, ph=ph))
        cols = ["#ffffff", C.accent2, C.accent, "#ffd6a5"]
        for _ in range(self.n):
            d = random.random()
            it = cv.create_oval(0, 0, 1, 1, fill=C.text, outline="", tags="fx")
            self.stars.append(dict(it=it, x=random.random() * max(1, self.W), y=random.random() * max(1, self.H), d=d,
                                   r=0.6 + d * 1.7, ph=random.random() * 6, sp=0.6 + random.random() * 2.2, col=random.choice(cols)))
        cv.tag_lower("fx")

    def set_enabled(self, on):
        self.enabled = on
        try: self.cv.itemconfigure("fx", state="normal" if on else "hidden")
        except tk.TclError: pass

    def step(self, dt, mouse=(0.5, 0.5), shooting=True):
        if not self.enabled or not self.W: return
        self.t += dt; t = self.t; cv = self.cv
        for o in self.orbs:
            cx = self.W * (0.5 + 0.42 * math.sin(t * o["f"][0] + o["ph"])); cy = self.H * (0.5 + 0.38 * math.cos(t * o["f"][1] + o["ph"] * 1.3))
            R = min(self.W, self.H) * 0.55
            for k, it in enumerate(o["rings"]):
                r = R * (1 - k / len(o["rings"])); cv.coords(it, cx - r, cy - r, cx + r, cy + r)
        ox, oy = (mouse[0] - 0.5) * 46, (mouse[1] - 0.5) * 30
        for s in self.stars:
            s["x"] -= (0.04 + 0.22 * s["d"]) * 60 * dt
            if s["x"] < -5: s["x"] = self.W + 5; s["y"] = random.random() * self.H
            x = s["x"] - ox * s["d"]; y = s["y"] - oy * s["d"]; r = s["r"]
            br = 0.3 + 0.7 * (math.sin(t * s["sp"] + s["ph"]) + 1) / 2
            cv.coords(s["it"], x - r, y - r, x + r, y + r); cv.itemconfigure(s["it"], fill=blend(self.bg, s["col"], br))
        if self.shoot and shooting:
            if self.sh is None and random.random() < 0.006:
                self.sh = dict(x=random.uniform(self.W * 0.3, self.W), y=random.uniform(0, self.H * 0.4), p=0.0,
                               it=cv.create_line(0, 0, 1, 1, fill=C.text, width=2, tags="fx"))
            elif self.sh:
                s = self.sh; s["p"] += dt * 1.4; p = s["p"]
                x = s["x"] - p * 380; y = s["y"] + p * 190
                cv.coords(s["it"], x, y, x + 90 * (1 - p * 0.5), y - 45 * (1 - p * 0.5))
                cv.itemconfigure(s["it"], fill=blend(C.accent2, self.bg, p))
                if p >= 1: cv.delete(s["it"]); self.sh = None


def make_planet(px, c1, c2):
    cx = cy = px // 2; R = int(px * 0.30)
    d1 = tuple(int(v * 0.16) for v in hex2rgb(c1)); l1 = tuple(min(255, int(a * 0.65 + b * 0.5)) for a, b in zip(hex2rgb(c1), hex2rgb(c2)))
    glow = Image.new("RGBA", (px, px), (0, 0, 0, 0))
    ImageDraw.Draw(glow).ellipse((cx - R * 1.4, cy - R * 1.4, cx + R * 1.4, cy + R * 1.4), fill=hex2rgb(c1) + (85,))
    glow = glow.filter(ImageFilter.GaussianBlur(px * 0.07))
    sph = Image.new("RGBA", (px, px), (0, 0, 0, 0)); sd = ImageDraw.Draw(sph)
    for i in range(R):
        t = i / R; r = R * (1 - t); o = -R * 0.38 * t
        col = tuple(int(d1[k] + (l1[k] - d1[k]) * t ** 0.75) for k in range(3))
        sd.ellipse((cx + o - r, cy + o - r, cx + o + r, cy + o + r), fill=col + (255,))
    bd = ImageDraw.Draw(sph, "RGBA")
    for k in range(7):
        y = cy - R + int(R * 2 * (k + 0.5) / 7); bd.line((cx - R, y, cx + R, y), fill=hex2rgb(c2) + (38,), width=max(2, R // 12))
    mask = Image.new("L", (px, px), 0); ImageDraw.Draw(mask).ellipse((cx - R, cy - R, cx + R, cy + R), fill=255); sph.putalpha(mask)
    box = (cx - R * 1.75, cy - R * 0.5, cx + R * 1.75, cy + R * 0.5)
    back = Image.new("RGBA", (px, px), (0, 0, 0, 0)); front = Image.new("RGBA", (px, px), (0, 0, 0, 0))
    for lay, a0, a1 in ((back, 180, 360), (front, 0, 180)):
        dr = ImageDraw.Draw(lay)
        dr.arc(box, a0, a1, fill=hex2rgb(c2) + (210,), width=max(3, int(R * 0.13)))
        b2 = (box[0] + R * 0.22, box[1] + R * 0.07, box[2] - R * 0.22, box[3] - R * 0.07)
        dr.arc(b2, a0, a1, fill=hex2rgb(c1) + (160,), width=max(2, int(R * 0.06)))
    back = back.rotate(-18, resample=Image.BICUBIC); front = front.rotate(-18, resample=Image.BICUBIC)
    out = Image.alpha_composite(glow, back); out = Image.alpha_composite(out, sph); return Image.alpha_composite(out, front)
