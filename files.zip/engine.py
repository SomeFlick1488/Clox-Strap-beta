"""Движок CloxStraper без интерфейса: конфиг, аккаунты, FFlags, моды, настройки Roblox, запуск."""
import base64, glob, hashlib, hmac, io, json, os, random, re, shutil, subprocess, sys, tempfile, time, webbrowser
from urllib.parse import quote
import requests
from PIL import Image, ImageDraw, ImageFont

APP, VERSION = "CloxStraper", "1.0.0"
IS_WIN = os.name == "nt"
LOCAL = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".local", "share")
DATA = os.path.join(LOCAL, APP)
BACKUP = os.path.join(DATA, "originals")
CFG_PATH = os.path.join(DATA, "config.json")
RBX = os.path.join(LOCAL, "Roblox")
XML_PATH = os.path.join(RBX, "GlobalBasicSettings_13.xml")
UA = {"User-Agent": "Mozilla/5.0"}
NOWIN = 0x08000000 if IS_WIN else 0

DEFAULT = {
    "theme": "Crimson", "font": "Comic Sans MS", "lang": "en", "sound": True, "scripts_tab": True,
    "acc_pass": None, "presets": [], "anim_style": "Smooth", "anim_speed": 1.0,
    "stars": True, "shooting": True, "parallax": True, "close_after_launch": False,
    "first_run_done": False, "accounts": [], "active": None, "fflags": {}, "rbx": {},
    "mods": {"cursor_on": False, "cursor_path": "", "cursor_size": 64, "font_on": False, "font_path": "",
             "sky_on": False, "sky_preset": "Deep Space", "sky_seed": 1, "sky_custom": ""},
    "shortcuts": [], "last_game": "", "old_protocol": None,
}

def load_cfg():
    c = json.loads(json.dumps(DEFAULT))
    try:
        with open(CFG_PATH, encoding="utf-8") as f: d = json.load(f)
        for k, v in d.items():
            if k == "mods" and isinstance(v, dict): c["mods"].update(v)
            else: c[k] = v
    except Exception:
        pass
    return c

def save_cfg(c):
    os.makedirs(DATA, exist_ok=True)
    tmp = CFG_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f: json.dump(c, f, indent=2, ensure_ascii=False)
    os.replace(tmp, CFG_PATH)


# ---------------------------------------------------------------- шифрование cookie (Windows DPAPI)
if IS_WIN:
    import ctypes
    from ctypes import wintypes
    class _BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]
    def _crypt(data, enc):
        buf = ctypes.create_string_buffer(data, len(data))
        inb = _BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))); out = _BLOB()
        fn = ctypes.windll.crypt32.CryptProtectData if enc else ctypes.windll.crypt32.CryptUnprotectData
        if not fn(ctypes.byref(inb), None, None, None, None, 0, ctypes.byref(out)): raise OSError("DPAPI error")
        try: return ctypes.string_at(out.pbData, out.cbData)
        finally: ctypes.windll.kernel32.LocalFree(out.pbData)

def protect(s):
    b = s.encode()
    if IS_WIN: b = _crypt(b, True)
    return base64.b64encode(b).decode()

def unprotect(s):
    b = base64.b64decode(s)
    if IS_WIN: b = _crypt(b, False)
    return b.decode()

def active_account(cfg):
    for a in cfg["accounts"]:
        if a["id"] == cfg.get("active"): return a
    return None


# ---------------------------------------------------------------- Roblox API
class Roblox:
    def __init__(self, cookie):
        self.cookie = cookie.strip()
        self.s = requests.Session(); self.s.headers.update(UA)
        self.s.cookies.set(".ROBLOSECURITY", self.cookie, domain=".roblox.com")
        self.uid = self.name = self.display = None

    def login(self):
        r = self.s.get("https://users.roblox.com/v1/users/authenticated", timeout=20)
        if r.status_code != 200: raise RuntimeError("Cookie не подошёл — проверь, что скопировал его целиком")
        d = r.json(); self.uid, self.name = d["id"], d["name"]; self.display = d.get("displayName") or d["name"]

    def avatar(self):
        try:
            j = requests.get("https://thumbnails.roblox.com/v1/users/avatar-headshot",
                             params={"userIds": self.uid, "size": "150x150", "format": "Png"}, timeout=15).json()
            return Image.open(io.BytesIO(requests.get(j["data"][0]["imageUrl"], timeout=15).content)).convert("RGBA")
        except Exception:
            return None

    def ticket(self, place_id):
        h = {"Referer": f"https://www.roblox.com/games/{place_id}", "Content-Type": "application/json"}
        for _ in range(3):
            r = self.s.post("https://auth.roblox.com/v1/authentication-ticket", headers=h, timeout=20)
            if r.status_code == 403 and "x-csrf-token" in r.headers:
                h["x-csrf-token"] = r.headers["x-csrf-token"]; continue
            break
        t = r.headers.get("rbx-authentication-ticket")
        if not t: raise RuntimeError("Не удалось получить ticket — cookie мог устареть, войди в аккаунт заново")
        return t

def login_password(user, pw):
    """Вход по нику и паролю. Пароль нигде не сохраняется. Captcha/2FA здесь не пройти — тогда нужен cookie."""
    s = requests.Session(); s.headers.update(UA)
    body = {"ctype": "Username", "cvalue": user, "password": pw}
    r = None
    for _ in range(3):
        r = s.post("https://auth.roblox.com/v2/login", json=body, timeout=25)
        if r.status_code == 403 and "x-csrf-token" in r.headers and "rblx-challenge-id" not in r.headers:
            s.headers["x-csrf-token"] = r.headers["x-csrf-token"]; continue
        break
    if "rblx-challenge-id" in r.headers or (r.status_code == 403 and "hallenge" in r.text):
        raise RuntimeError("Roblox требует captcha / 2-step проверку. Войди через Cookie.")
    if r.status_code != 200:
        try: msg = r.json()["errors"][0]["message"]
        except Exception: msg = f"Ошибка входа ({r.status_code})"
        raise RuntimeError(msg)
    ck = s.cookies.get(".ROBLOSECURITY")
    if not ck: raise RuntimeError("Roblox не вернул cookie. Войди через Cookie.")
    return ck

def game_info(pid):
    try:
        u = requests.get(f"https://apis.roblox.com/universes/v1/places/{pid}/universe", headers=UA, timeout=15).json()["universeId"]
        name = requests.get("https://games.roblox.com/v1/games", params={"universeIds": u}, headers=UA, timeout=15).json()["data"][0]["name"]
    except Exception:
        return None, None
    img = None
    try:
        j = requests.get("https://thumbnails.roblox.com/v1/games/icons", params={"universeIds": u, "size": "150x150", "format": "Png"}, timeout=15).json()
        img = Image.open(io.BytesIO(requests.get(j["data"][0]["imageUrl"], timeout=15).content)).convert("RGBA")
    except Exception:
        pass
    return name, img

def parse_place(text):
    text = (text or "").strip()
    if text.isdigit(): return int(text)
    m = re.search(r"games/(\d+)", text) or re.search(r"placeId=(\d+)", text)
    return int(m.group(1)) if m else None


# ---------------------------------------------------------------- поиск Roblox
def version_dirs():
    roots = [os.path.join(RBX, "Versions")]
    for pf in (os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles")):
        if pf: roots.append(os.path.join(pf, "Roblox", "Versions"))
    found = [d for r in roots for d in glob.glob(os.path.join(glob.escape(r), "version-*"))
             if os.path.exists(os.path.join(d, "RobloxPlayerBeta.exe"))]
    return sorted(found, key=os.path.getmtime, reverse=True)

def newest_version():
    v = version_dirs(); return v[0] if v else None

def player_exe():
    v = newest_version(); return os.path.join(v, "RobloxPlayerBeta.exe") if v else None


# ---------------------------------------------------------------- настройки Roblox Editor
SETTINGS = []
def _add(section, key, kind, label, default, **kw):
    SETTINGS.append(dict(section=section, key=key, kind=kind, label=label, default=default, **kw))

_add("Graphics", "fps_on", "switch", "Unlock FPS cap", False)
_add("Graphics", "fps", "slider", "Target FPS", 144, lo=30, hi=1000, step=10)
_add("Graphics", "quality", "slider", "Graphics quality (0 = Auto)", 0, lo=0, hi=10, step=1)
_add("Graphics", "fullscreen", "switch", "Fullscreen", False)
_add("Graphics", "api", "menu", "Rendering API", "Default", opts=["Default", "Direct3D 11", "Vulkan", "OpenGL"])
_add("Graphics", "lighting", "menu", "Lighting technology", "Default", opts=["Default", "Voxel", "ShadowMap", "Future"])
_add("Graphics", "msaa", "menu", "Anti-aliasing (MSAA)", "Default", opts=["Default", "Off", "2x", "4x", "8x"])
_add("Graphics", "texture", "menu", "Texture quality", "Default", opts=["Default", "Lowest", "Low", "Medium", "High"])
_add("Graphics", "no_shadows", "switch", "Disable shadows", False)
_add("Graphics", "no_postfx", "switch", "Disable post-processing", False)
_add("Graphics", "no_grass", "switch", "Disable grass", False)
_add("Graphics", "gray_sky", "switch", "Gray sky (performance)", False)
_add("Graphics", "alt_enter", "switch", "Fix Alt+Enter fullscreen", False)
_add("Interface", "stats", "switch", "Show performance stats", False)
_add("Interface", "chat", "switch", "Show chat", True)
_add("Interface", "maximized", "switch", "Start maximized", False)
_add("Audio", "volume", "slider", "Master volume", 100, lo=0, hi=100, step=1)
_add("Input", "sens", "slider", "Mouse sensitivity", 1.0, lo=0.1, hi=4.0, step=0.1, fmt="{:.1f}")
_add("Input", "invert", "switch", "Invert camera Y", False)

def settings_to_changes(r):
    f, x = {}, {}
    if r.get("fps_on"): f["DFIntTaskSchedulerTargetFps"] = int(r.get("fps", 144))
    api = r.get("api", "Default")
    if api == "Direct3D 11": f["FFlagDebugGraphicsPreferD3D11"] = True
    elif api == "Vulkan": f["FFlagDebugGraphicsPreferVulkan"] = True
    elif api == "OpenGL": f["FFlagDebugGraphicsPreferOpenGL"] = True
    lt = r.get("lighting", "Default")
    if lt == "Voxel": f["DFFlagDebugRenderForceTechnologyVoxel"] = True
    elif lt == "ShadowMap": f["FFlagDebugForceFutureIsBrightPhase2"] = True
    elif lt == "Future": f["FFlagDebugForceFutureIsBrightPhase3"] = True
    m = r.get("msaa", "Default")
    if m != "Default": f["FIntDebugForceMSAASamples"] = {"Off": 1, "2x": 2, "4x": 4, "8x": 8}[m]
    t = r.get("texture", "Default")
    if t != "Default":
        f["DFFlagTextureQualityOverrideEnabled"] = True
        f["DFIntTextureQualityOverride"] = {"Lowest": 0, "Low": 1, "Medium": 2, "High": 3}[t]
    if r.get("no_shadows"): f["FIntRenderShadowIntensity"] = 0
    if r.get("no_postfx"): f["FFlagDisablePostFx"] = True
    if r.get("no_grass"): f.update(FIntFRMMinGrassDistance=0, FIntFRMMaxGrassDistance=0, FIntRenderGrassDetailStrands=0)
    if r.get("gray_sky"): f["FFlagDebugSkyGray"] = True
    if r.get("alt_enter"): f["FFlagHandleAltEnterFullscreenManually"] = False
    if "fullscreen" in r: x["Fullscreen"] = ("bool", bool(r["fullscreen"]))
    if "stats" in r: x["PerformanceStatsVisible"] = ("bool", bool(r["stats"]))
    if "chat" in r: x["ChatVisible"] = ("bool", bool(r["chat"]))
    if "maximized" in r: x["StartMaximized"] = ("bool", bool(r["maximized"]))
    if "invert" in r: x["CameraYInverted"] = ("bool", bool(r["invert"]))
    if "volume" in r: x["MasterVolume"] = ("float", round(float(r["volume"]) / 100, 3))
    if "sens" in r: x["MouseSensitivity"] = ("float", round(float(r["sens"]), 2))
    if "quality" in r:
        q = int(r["quality"]); x["GraphicsQualityLevel"] = ("int", q or 1); x["SavedQualityLevel"] = ("token", q)
    return f, x

PRESETS = {
    "FPS unlock (144)": {"DFIntTaskSchedulerTargetFps": 144},
    "FPS unlock (240)": {"DFIntTaskSchedulerTargetFps": 240},
    "Low-end PC": {"FIntRenderShadowIntensity": 0, "FFlagDisablePostFx": True, "DFFlagTextureQualityOverrideEnabled": True,
                   "DFIntTextureQualityOverride": 0, "FIntFRMMaxGrassDistance": 0},
    "Gray sky": {"FFlagDebugSkyGray": True},
    "Voxel lighting": {"DFFlagDebugRenderForceTechnologyVoxel": True},
    "Fix Alt+Enter": {"FFlagHandleAltEnterFullscreenManually": False},
}

def parse_flag_value(s):
    s = s.strip(); low = s.lower()
    if low in ("true", "false"): return low == "true"
    try: return int(s)
    except ValueError: pass
    try: return float(s)
    except ValueError: return s

def fmt_flag_value(v):
    return "True" if v is True else "False" if v is False else str(v)

def set_xml(updates):
    """Правит GlobalBasicSettings_13.xml. Roblox должен быть закрыт."""
    if not updates or not os.path.exists(XML_PATH): return False
    with open(XML_PATH, encoding="utf-8") as f: s = f.read()
    for name, (typ, val) in updates.items():
        v = ("true" if val else "false") if typ == "bool" else str(val)
        pat = re.compile(r'<(bool|int|float|token|string) name="%s">(.*?)</\1>' % re.escape(name))
        if pat.search(s):
            s = pat.sub(lambda m: f'<{m.group(1)} name="{name}">{v}</{m.group(1)}>', s, count=1)
        else:
            s = s.replace("</Properties>", f'\t\t\t<{typ} name="{name}">{v}</{typ}>\n\t\t</Properties>', 1)
    with open(XML_PATH, "w", encoding="utf-8") as f: f.write(s)
    return True

def build_flags(cfg):
    f, _ = settings_to_changes(cfg["rbx"])
    f.update(cfg["fflags"])
    return {k: fmt_flag_value(v) for k, v in f.items()}

def write_flags(flags, ver):
    d = os.path.join(ver, "ClientSettings"); p = os.path.join(d, "ClientAppSettings.json")
    if not flags:
        if os.path.exists(p): os.remove(p)
        return
    os.makedirs(d, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f: json.dump(flags, f, indent=2)


# ---------------------------------------------------------------- моды: курсор / шрифт / небо
FACES = ["bk", "dn", "ft", "lf", "rt", "up"]
SKY_PRESETS = {
    "Deep Space": ((4, 6, 20), (22, 10, 48), True), "Midnight": ((2, 2, 8), (8, 12, 30), True),
    "Aurora": ((3, 12, 20), (10, 90, 80), True), "Sunset": ((40, 20, 80), (255, 120, 80), False),
    "Pink Dream": ((70, 30, 120), (255, 150, 200), False), "Doors Hotel": ((8, 5, 3), (46, 24, 10), False),
}

def make_sky(preset, seed=1, custom=None):
    if preset == "Custom image" and custom and os.path.exists(custom):
        im = Image.open(custom).convert("RGB").resize((512, 512), Image.LANCZOS)
        return {f: im for f in FACES}
    top, bot, stars = SKY_PRESETS.get(preset, SKY_PRESETS["Deep Space"])
    rnd = random.Random(seed); out = {}
    for f in FACES:
        im = Image.new("RGB", (512, 512)); d = ImageDraw.Draw(im)
        for y in range(512):
            c = top if f == "up" else bot if f == "dn" else tuple(int(a + (b - a) * (y / 511) ** 1.6) for a, b in zip(top, bot))
            d.line([(0, y), (511, y)], fill=c)
        if stars and f != "dn":
            for _ in range(170 if f == "up" else 100):
                x, y = rnd.randrange(512), rnd.randrange(512 if f == "up" else 380); b = rnd.randint(110, 255)
                d.rectangle((x, y, x + (1 if rnd.random() < 0.25 else 0), y + (1 if rnd.random() < 0.25 else 0)), fill=(b, b, b))
        out[f] = im
    return out

def _backup_file(ver, dst):
    b = os.path.join(BACKUP, os.path.relpath(dst, ver))
    if os.path.exists(dst) and not os.path.exists(b):
        os.makedirs(os.path.dirname(b), exist_ok=True); shutil.copy2(dst, b)

def _restore_group(ver, prefix):
    root = os.path.join(BACKUP, prefix); n = 0
    for dp, _, files in os.walk(root):
        for fn in files:
            src = os.path.join(dp, fn); dst = os.path.join(ver, os.path.relpath(src, BACKUP))
            os.makedirs(os.path.dirname(dst), exist_ok=True); shutil.copy2(src, dst); n += 1
    return n

def apply_mods(cfg, log=print, ver=None):
    ver = ver or newest_version()
    if not ver: log("Roblox не найден — моды пропущены"); return False
    m = cfg["mods"]
    cur = os.path.join("content", "textures", "Cursors"); fonts = os.path.join("content", "fonts"); sky = os.path.join("content", "sky")
    # курсор
    if m["cursor_on"] and os.path.exists(m["cursor_path"] or ""):
        sz = int(m.get("cursor_size", 64)); img = Image.open(m["cursor_path"]).convert("RGBA").resize((sz, sz), Image.LANCZOS)
        d = os.path.join(ver, cur, "KeyboardMouse"); os.makedirs(d, exist_ok=True)
        for n in ("ArrowCursor.png", "ArrowFarCursor.png"):
            _backup_file(ver, os.path.join(d, n)); img.save(os.path.join(d, n), "PNG")
        log("Курсор применён")
    else:
        _restore_group(ver, cur)
    # шрифт
    if m["font_on"] and os.path.exists(m["font_path"] or ""):
        ext = os.path.splitext(m["font_path"])[1].lower() or ".ttf"; fd = os.path.join(ver, fonts)
        os.makedirs(fd, exist_ok=True); shutil.copy2(m["font_path"], os.path.join(fd, "CustomFont" + ext))
        for jp in glob.glob(os.path.join(glob.escape(fd), "families", "*.json")):
            _backup_file(ver, jp)
            with open(jp, encoding="utf-8") as f: data = json.load(f)
            for face in data.get("faces", []): face["assetId"] = f"rbxasset://fonts/CustomFont{ext}"
            with open(jp, "w", encoding="utf-8") as f: json.dump(data, f, indent=2)
        log("Шрифт применён")
    else:
        _restore_group(ver, fonts)
    # небо
    if m["sky_on"]:
        sd = os.path.join(ver, sky); os.makedirs(sd, exist_ok=True)
        imgs = make_sky(m["sky_preset"], m["sky_seed"], m["sky_custom"])
        existing = glob.glob(os.path.join(glob.escape(sd), "*.tex"))
        targets = {}
        for p in existing:
            mm = re.search(r"_(bk|dn|ft|lf|rt|up)\.", os.path.basename(p))
            if mm: targets[mm.group(1)] = p
        for face in FACES: targets.setdefault(face, os.path.join(sd, f"sky512_{face}.tex"))
        for face, p in targets.items():
            _backup_file(ver, p); imgs[face].save(p, "PNG")
        log("Небо применено")
    else:
        _restore_group(ver, sky)
    return True

def restore_all(log=print):
    ver = newest_version()
    if not ver: return 0
    n = sum(_restore_group(ver, p) for p in (os.path.join("content", "textures", "Cursors"), os.path.join("content", "fonts"), os.path.join("content", "sky")))
    log(f"Восстановлено файлов: {n}"); return n


# ---------------------------------------------------------------- применение всего + запуск
def apply_all(cfg, log=print):
    ver = newest_version()
    if not ver: raise RuntimeError("Roblox не установлен. Нажми «Install Roblox» на вкладке Launch.")
    log("Применяю FFlags…"); write_flags(build_flags(cfg), ver)
    log("Применяю настройки Roblox…")
    _, xml = settings_to_changes(cfg["rbx"])
    try: set_xml(xml)
    except Exception as e: log(f"Настройки не записались: {e}")
    log("Применяю моды…"); apply_mods(cfg, log, ver)
    return ver

def _spawn(args):
    kw = {"creationflags": 0x00000008 | 0x00000200} if IS_WIN else {}
    subprocess.Popen(args, close_fds=True, **kw)

def launch_game(cfg, place_id, log=print, job=None):
    apply_all(cfg, log)
    exe = player_exe(); acc = active_account(cfg)
    if place_id and acc:
        log("Получаю ключ входа…")
        r = Roblox(unprotect(acc["cookie"])); ticket = r.ticket(place_id)
        tracker = random.randint(10 ** 10, 10 ** 11 - 1)
        req = f"RequestGameJob&browserTrackerId={tracker}&placeId={place_id}&gameId={job}" if job else f"RequestGame&browserTrackerId={tracker}&placeId={place_id}"
        url = f"https://assetgame.roblox.com/game/PlaceLauncher.ashx?request={req}&isPlayTogetherGame=false"
        uri = (f"roblox-player:1+launchmode:play+gameinfo:{ticket}+launchtime:{int(time.time() * 1000)}"
               f"+placelauncherurl:{quote(url, safe='')}+browsertrackerid:{tracker}+robloxLocale:en_us+gameLocale:en_us+channel:+LaunchExp:InApp")
        log("Запускаю Roblox…"); _spawn([exe, uri])
    elif place_id:
        log("Нет аккаунта — открываю страницу игры…"); webbrowser.open(f"https://www.roblox.com/games/{place_id}")
    else:
        log("Открываю Roblox…"); webbrowser.open("https://www.roblox.com/home")

def handle_uri(cfg, uri):
    """Вызывается, когда сайт Roblox открывает roblox-player:… через наш лаунчер."""
    apply_all(cfg, lambda *_: None); _spawn([player_exe(), uri])

def install_roblox(log=print):
    log("Скачиваю установщик Roblox…")
    r = requests.get("https://www.roblox.com/download/client", headers=UA, timeout=60, allow_redirects=True)
    r.raise_for_status()
    p = os.path.join(tempfile.gettempdir(), "RobloxPlayerInstaller.exe")
    with open(p, "wb") as f: f.write(r.content)
    log("Запускаю установщик Roblox…"); _spawn([p])


# ---------------------------------------------------------------- обработчик roblox-player:
def register_protocol(cfg, exe):
    import winreg
    key = r"Software\Classes\roblox-player"; cmd = key + r"\shell\open\command"
    try: old = winreg.QueryValue(winreg.HKEY_CURRENT_USER, cmd)
    except OSError: old = None
    if old and APP.lower() not in old.lower() and not cfg.get("old_protocol"): cfg["old_protocol"] = old
    winreg.SetValue(winreg.HKEY_CURRENT_USER, key, winreg.REG_SZ, "URL: Roblox Protocol")
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key) as k: winreg.SetValueEx(k, "URL Protocol", 0, winreg.REG_SZ, "")
    winreg.SetValue(winreg.HKEY_CURRENT_USER, cmd, winreg.REG_SZ, f'"{exe}" "%1"')

def unregister_protocol(cfg):
    import winreg
    key = r"Software\Classes\roblox-player"; cmd = key + r"\shell\open\command"
    if cfg.get("old_protocol"):
        winreg.SetValue(winreg.HKEY_CURRENT_USER, cmd, winreg.REG_SZ, cfg["old_protocol"]); cfg["old_protocol"] = None
    else:
        for k in (cmd, key + r"\shell\open", key + r"\shell", key):
            try: winreg.DeleteKey(winreg.HKEY_CURRENT_USER, k)
            except OSError: pass


# ---------------------------------------------------------------- пароль для вкладки Accounts
def _hash(pw, salt): return hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, 200_000)

def set_password(cfg, pw):
    salt = os.urandom(16); cfg["acc_pass"] = {"salt": salt.hex(), "hash": _hash(pw, salt).hex()}

def check_password(cfg, pw):
    p = cfg.get("acc_pass")
    return bool(p) and hmac.compare_digest(_hash(pw, bytes.fromhex(p["salt"])).hex(), p["hash"])


# ---------------------------------------------------------------- друзья, которые сейчас играют
def friends_in_game(cookie, uid):
    s = requests.Session(); s.headers.update(UA); s.cookies.set(".ROBLOSECURITY", cookie, domain=".roblox.com")
    r = s.get(f"https://friends.roblox.com/v1/users/{uid}/friends", timeout=20); r.raise_for_status()
    fr = {f["id"]: f for f in r.json().get("data", [])}; ids = list(fr); out = []; h = {"Content-Type": "application/json"}
    for i in range(0, len(ids), 50):
        p = None
        for _ in range(3):
            p = s.post("https://presence.roblox.com/v1/presence/users", json={"userIds": ids[i:i + 50]}, headers=h, timeout=20)
            if p.status_code == 403 and "x-csrf-token" in p.headers: h["x-csrf-token"] = p.headers["x-csrf-token"]; continue
            break
        if p is None or p.status_code != 200: continue
        for u in p.json().get("userPresences", []):
            if u.get("userPresenceType") == 2:
                f = fr.get(u["userId"], {})
                out.append(dict(id=u["userId"], name=f.get("name", ""), display=f.get("displayName") or f.get("name", ""), loc=u.get("lastLocation", ""),
                                place=u.get("rootPlaceId") or u.get("placeId"), job=u.get("gameId"), img=None))
    for i in range(0, len(out), 50):
        chunk = out[i:i + 50]
        try:
            j = requests.get("https://thumbnails.roblox.com/v1/users/avatar-headshot", params={"userIds": ",".join(str(f["id"]) for f in chunk),
                             "size": "48x48", "format": "Png"}, timeout=20).json()
            urls = {d["targetId"]: d.get("imageUrl") for d in j.get("data", [])}
        except Exception: urls = {}
        for f in chunk:
            try: f["img"] = Image.open(io.BytesIO(requests.get(urls[f["id"]], timeout=15).content)).convert("RGBA")
            except Exception: pass
    return out


# ---------------------------------------------------------------- ScriptBlox (только просмотр и копирование, без запуска)
def scriptblox(query="", page=1):
    if query: url, params = "https://scriptblox.com/api/script/search", {"q": query, "page": page, "max": 20, "mode": "free"}
    else: url, params = "https://scriptblox.com/api/script/fetch", {"page": page}
    r = requests.get(url, params=params, headers=UA, timeout=20); r.raise_for_status()
    res = r.json().get("result", {}); out = []
    for sc in res.get("scripts", []):
        g = sc.get("game") or {}
        out.append(dict(title=sc.get("title") or "?", game=g.get("name") or ("Universal" if sc.get("isUniversal") else "?"), key=bool(sc.get("key")),
                        verified=bool(sc.get("verified")), patched=bool(sc.get("isPatched")), views=sc.get("views", 0),
                        code=sc.get("script") or "", slug=sc.get("slug") or ""))
    return out, int(res.get("totalPages", 1) or 1)


# ---------------------------------------------------------------- пресеты конфигов
BUILTIN_PRESETS = [
    dict(name="Doors theme", icon="🚪", desc="Dark hotel look: amber & blood-red theme, gloomy sky and a golden cursor.", theme="Doors",
         rbx={}, fflags={}, mods=dict(sky_on=True, sky_preset="Doors Hotel", cursor_on=True), doors_cursor=True),
    dict(name="Cosmic", icon="🌌", desc="Purple nebula theme with a deep-space sky.", theme="Nebula", mods=dict(sky_on=True, sky_preset="Deep Space")),
    dict(name="Max FPS", icon="⚡", desc="Unlocked 360 FPS, Direct3D 11, no post-processing or shadows.",
         rbx=dict(fps_on=True, fps=360, api="Direct3D 11", no_shadows=True, no_postfx=True, texture="Low")),
    dict(name="Low-end PC", icon="🥔", desc="Everything turned down to squeeze out performance.",
         rbx=dict(fps_on=True, fps=144, quality=1, no_shadows=True, no_postfx=True, no_grass=True, texture="Lowest", gray_sky=True)),
    dict(name="Pretty", icon="✨", desc="Max quality: Future lighting, 4x MSAA, high textures.", rbx=dict(quality=10, lighting="Future", msaa="4x", texture="High")),
    dict(name="Roblox defaults", icon="↺", desc="Clears all tweaks, flags and mods.", rbx={}, fflags={}, mods=dict(cursor_on=False, font_on=False, sky_on=False)),
]

def make_doors_cursor():
    os.makedirs(DATA, exist_ok=True); path = os.path.join(DATA, "doors_cursor.png")
    big = Image.new("RGBA", (256, 256), (0, 0, 0, 0)); d = ImageDraw.Draw(big)
    pts = [(24, 16), (24, 192), (72, 148), (108, 232), (140, 216), (104, 134), (168, 134)]
    d.polygon(pts, fill=(217, 164, 65, 255), outline=(25, 12, 5, 255)); d.line(pts + [pts[0]], fill=(25, 12, 5, 255), width=12, joint="curve")
    d.line([(34, 40), (34, 150)], fill=(255, 224, 150, 255), width=8)
    big.resize((64, 64), Image.LANCZOS).save(path, "PNG"); return path
