"""Переводы интерфейса: ключ = английский текст. Языки: en (по умолчанию), uk, ru."""
LANG = {"code": "en"}
LANG_NAMES = {"uk": "Українська", "ru": "Русский", "en": "English"}

def set_lang(code): LANG["code"] = code if code in LANG_NAMES else "en"

def T(s):
    return TR.get(LANG["code"], {}).get(s, s)

# fmt: off
_RAW = """
Account removed | Акаунт видалено | Аккаунт удалён
Accounts | Акаунти | Аккаунты
Accounts are locked | Акаунти заблоковано | Аккаунты заблокированы
Active account changed | Активний акаунт змінено | Активный аккаунт изменён
Added “{name}” — press Save | Додано «{name}» — натисни Save | Добавлено «{name}» — нажми Save
Adding… | Додаю… | Добавляю…
Animation speed | Швидкість анімацій | Скорость анимаций
Animation type | Тип анімацій | Тип анимаций
Anti-aliasing (MSAA) | Згладжування (MSAA) | Сглаживание (MSAA)
Applied to Roblox ✓ | Застосовано до Roblox ✓ | Применено к Roblox ✓
Apply | Застосувати | Применить
At least 4 characters | Мінімум 4 символи | Минимум 4 символа
Built-in | Вбудовані | Встроенные
Cancel | Скасувати | Отмена
Change password | Змінити пароль | Сменить пароль
Cheating breaks Roblox's rules, ruins the game for other players and can get your account banned. Scripts from the internet can also hide malware that steals your account. CloxStraper only shows and copies code — it never runs it. | Чити порушують правила Roblox, псують гру іншим гравцям і можуть призвести до бану акаунта. Скрипти з інтернету також можуть ховати шкідливий код, що краде акаунт. CloxStraper лише показує й копіює код — він його ніколи не запускає. | Читы нарушают правила Roblox, портят игру другим игрокам и могут привести к бану аккаунта. Скрипты из интернета также могут скрывать вредоносный код, который крадёт аккаунт. CloxStraper только показывает и копирует код — он его никогда не запускает.
Checking… | Перевіряю… | Проверяю…
Choose a new password. | Придумай новий пароль. | Придумай новый пароль.
Choose font… | Обрати шрифт… | Выбрать шрифт…
Choose image… | Обрати зображення… | Выбрать изображение…
Choose your language | Обери мову | Выбери язык
Clear | Очистити | Очистить
Clears all tweaks, flags and mods. | Скидає всі налаштування, флаги та моди. | Сбрасывает все настройки, флаги и моды.
Click again: this DELETES all saved accounts | Натисни ще раз: це ВИДАЛИТЬ усі збережені акаунти | Нажми ещё раз: это УДАЛИТ все сохранённые аккаунты
Click sounds | Звуки кліків | Звуки кликов
Client theme | Тема клієнта | Тема клиента
Close CloxStraper after launching Roblox | Закривати CloxStraper після запуску Roblox | Закрывать CloxStraper после запуска Roblox
Close Roblox before applying.  Only changed settings are written. | Закрий Roblox перед застосуванням. Записуються лише змінені налаштування. | Закрой Roblox перед применением. Записываются только изменённые настройки.
CloxStraper is now your Roblox launcher ✓ | CloxStraper тепер твій лаунчер Roblox ✓ | CloxStraper теперь твой лаунчер Roblox ✓
CloxStraper is ready for launch 🚀 | CloxStraper готовий до запуску 🚀 | CloxStraper готов к запуску 🚀
Cookie | Cookie | Cookie
Copied. Remember: cheating can get you banned. | Скопійовано. Пам'ятай: за чити можуть забанити. | Скопировано. Помни: за читы могут забанить.
Copy | Копіювати | Копировать
Cosmic | Космос | Космос
Couldn't load friends | Не вдалося завантажити друзів | Не удалось загрузить друзей
Couldn't reach ScriptBlox | Не вдалося зв'язатися зі ScriptBlox | Не удалось связаться со ScriptBlox
Couldn't read that game link / Place ID | Не вдалося прочитати посилання / Place ID | Не удалось прочитать ссылку / Place ID
Create accounts password | Створи пароль для акаунтів | Создай пароль для аккаунтов
Cursor selected | Курсор обрано | Курсор выбран
Custom cursor, font and sky — applied on every launch | Свій курсор, шрифт і небо — застосовуються при кожному запуску | Свой курсор, шрифт и небо — применяются при каждом запуске
Dark hotel look: amber & blood-red theme, gloomy sky and a golden cursor. | Темний готель: бурштиново-криваві кольори, похмуре небо та золотий курсор. | Тёмный отель: янтарно-кровавые цвета, мрачное небо и золотой курсор.
Disable grass | Вимкнути траву | Отключить траву
Disable post-processing | Вимкнути постобробку | Отключить постобработку
Disable shadows | Вимкнути тіні | Отключить тени
Doors theme | Тема Doors | Тема Doors
Downloading… | Завантажую… | Скачиваю…
Enable custom cursor | Увімкнути свій курсор | Включить свой курсор
Enable custom font | Увімкнути свій шрифт | Включить свой шрифт
Enable custom sky | Увімкнути своє небо | Включить своё небо
Enter username and password | Введи нік і пароль | Введи ник и пароль
Enter your password to continue. | Введи пароль, щоб продовжити. | Введи пароль, чтобы продолжить.
Everything turned down to squeeze out performance. | Усе мінімально — щоб вичавити максимум продуктивності. | Всё по минимуму — чтобы выжать максимум производительности.
Export | Експорт | Экспорт
Exported | Експортовано | Экспортировано
FFlag Editor | Редактор FFlag | Редактор FFlag
Fast Flags — hidden Roblox engine switches | Fast Flags — приховані перемикачі рушія Roblox | Fast Flags — скрытые переключатели движка Roblox
Fix Alt+Enter fullscreen | Виправити повний екран Alt+Enter | Исправить полный экран Alt+Enter
Font | Шрифт | Шрифт
Font selected | Шрифт обрано | Шрифт выбран
Forgot password? | Забув пароль? | Забыл пароль?
Fullscreen | Повний екран | Полный экран
Game link or Place ID | Посилання на гру або Place ID | Ссылка на игру или Place ID
Game link or Place ID (optional) | Посилання на гру або Place ID (необов'язково) | Ссылка на игру или Place ID (необязательно)
Generated skies — or use your own picture on all six faces. | Згенеровані небеса — або своя картинка на всіх шести гранях. | Сгенерированные небеса — или своя картинка на всех шести гранях.
Give your preset a name | Дай пресету назву | Дай пресету название
Graphics quality (0 = Auto) | Якість графіки (0 = авто) | Качество графики (0 = авто)
Gray sky (performance) | Сіре небо (продуктивність) | Серое небо (производительность)
Guest mode — no account (add one in Accounts) | Гостьовий режим — без акаунта (додай у вкладці Акаунти) | Гостевой режим — без аккаунта (добавь во вкладке Аккаунты)
Import | Імпорт | Импорт
Imported {n} flags — press Save | Імпортовано флагів: {n} — натисни Save | Импортировано флагов: {n} — нажми Save
Invert camera Y | Інвертувати камеру по Y | Инвертировать камеру по Y
It will be asked every time you open this tab. | Його питатимуть щоразу, коли відкриваєш цю вкладку. | Его будут спрашивать каждый раз при открытии этой вкладки.
It's me!  ➜ | Це я!  ➜ | Это я!  ➜
LAUNCH ROBLOX | ЗАПУСТИТИ ROBLOX | ЗАПУСТИТЬ ROBLOX
LAUNCHING… | ЗАПУСКАЮ… | ЗАПУСКАЮ…
Language | Мова | Язык
Later | Пізніше | Позже
Launch | Запуск | Запуск
Let's get everything ready — it only takes a minute ✦ | Давай усе підготуємо — це займе хвилину ✦ | Давай всё подготовим — это займёт минуту ✦
Let's go  ➜ | Поїхали  ➜ | Поехали  ➜
Lighting technology | Технологія освітлення | Технология освещения
Loading friends… | Завантажую друзів… | Загружаю друзей…
Loading scripts… | Завантажую скрипти… | Загружаю скрипты…
Log in  ➜ | Увійти  ➜ | Войти  ➜
Log in to Roblox | Увійди в Roblox | Войди в Roblox
Log in to see which friends are playing | Увійди, щоб бачити, хто з друзів грає | Войди, чтобы видеть, кто из друзей играет
Log in with a cookie or a username & password | Вхід за cookie або за ніком і паролем | Вход по cookie или по нику и паролю
Logging in… | Входжу… | Вхожу…
Low-end PC | Слабкий ПК | Слабый ПК
Make CloxStraper yours | Налаштуй CloxStraper під себе | Настрой CloxStraper под себя
Master volume | Загальна гучність | Общая громкость
Max FPS | Макс. FPS | Макс. FPS
Max quality: Future lighting, 4x MSAA, high textures. | Макс. якість: освітлення Future, MSAA 4x, високі текстури. | Макс. качество: освещение Future, MSAA 4x, высокие текстуры.
Modifications | Модифікації | Модификации
Mouse parallax | Паралакс від миші | Параллакс от мыши
Mouse sensitivity | Чутливість миші | Чувствительность мыши
My presets | Мої пресети | Мои пресеты
Name (optional) | Назва (необов'язково) | Название (необязательно)
Name for your preset | Назва твого пресета | Название твоего пресета
New password | Новий пароль | Новый пароль
No accounts yet — add one above.\\nYou can also play as guest from the Launch tab. | Акаунтів ще немає — додай вище.\\nМожна також грати гостем із вкладки Запуск. | Аккаунтов пока нет — добавь выше.\\nМожно также играть гостем со вкладки Запуск.
No code in the listing — use Open | У списку немає коду — натисни Open | В списке нет кода — нажми Open
No connection to Roblox | Немає зв'язку з Roblox | Нет связи с Roblox
No friends are in this game right now | Зараз жоден друг не грає в цю гру | Сейчас ни один друг не играет в эту игру
No scripts found | Скриптів не знайдено | Скриптов не найдено
None of your friends are playing right now | Зараз ніхто з друзів не грає | Сейчас никто из друзей не играет
Not affiliated with Roblox Corporation. Use at your own risk — modifying the client may break after Roblox updates. | Не пов'язано з Roblox Corporation. Використовуй на свій ризик — зміни клієнта можуть зламатися після оновлень Roblox. | Не связано с Roblox Corporation. Используй на свой риск — изменения клиента могут сломаться после обновлений Roblox.
Nothing saved yet — set up Roblox the way you like and press Save. | Поки нічого не збережено — налаштуй Roblox як тобі подобається й натисни Save. | Пока ничего не сохранено — настрой Roblox как нравится и нажми Save.
Nothing to restore | Нічого відновлювати | Нечего восстанавливать
One-click configs — or save your own | Конфіги в один клік — або збережи свій | Конфиги в один клик — или сохрани свой
Open | Відкрити | Открыть
Original launcher restored | Оригінальний лаунчер відновлено | Оригинальный лаунчер восстановлен
Password | Пароль | Пароль
Password is never saved. If Roblox asks for captcha / 2-step verification, use the Cookie method. | Пароль ніколи не зберігається. Якщо Roblox просить капчу / 2FA — використай вхід через Cookie. | Пароль никогда не сохраняется. Если Roblox просит капчу / 2FA — используй вход через Cookie.
Password saved | Пароль збережено | Пароль сохранён
Passwords don't match | Паролі не збігаються | Пароли не совпадают
Paste | Вставити | Вставить
Paste your .ROBLOSECURITY cookie — or skip and add it later. | Встав cookie .ROBLOSECURITY — або пропусти й додай пізніше. | Вставь cookie .ROBLOSECURITY — или пропусти и добавь позже.
Paste your .ROBLOSECURITY first | Спочатку встав .ROBLOSECURITY | Сначала вставь .ROBLOSECURITY
Playing as  {name}  (@{user}) | Граєш як  {name}  (@{user}) | Играешь как  {name}  (@{user})
Preset applied — it takes effect on next launch | Пресет застосовано — набуде чинності при наступному запуску | Пресет применён — вступит в силу при следующем запуске
Preset “{name}” saved | Пресет «{name}» збережено | Пресет «{name}» сохранён
Presets | Пресети | Пресеты
Pretty | Краса | Красота
Protect your accounts | Захисти свої акаунти | Защити свои аккаунты
Public scripts from ScriptBlox — view & copy only | Публічні скрипти зі ScriptBlox — лише перегляд і копіювання | Публичные скрипты со ScriptBlox — только просмотр и копирование
Purple nebula theme with a deep-space sky. | Фіолетова тема туманності з глибоким космічним небом. | Фиолетовая тема туманности с глубоким космическим небом.
Quick add… | Швидко додати… | Быстро добавить…
Ready for launch | Готовий до запуску | Готов к запуску
Rendering API | API рендерингу | API рендеринга
Repeat password | Повтори пароль | Повтори пароль
Replaces all Roblox UI fonts with your .ttf / .otf font. | Замінює всі шрифти інтерфейсу Roblox твоїм .ttf / .otf. | Заменяет все шрифты интерфейса Roblox твоим .ttf / .otf.
Restore original | Відновити оригінал | Восстановить оригинал
Restored {n} original files | Відновлено оригінальних файлів: {n} | Восстановлено оригинальных файлов: {n}
Roblox Editor | Редактор Roblox | Редактор Roblox
Roblox Editor reset | Редактор Roblox скинуто | Редактор Roblox сброшен
Roblox defaults | Налаштування Roblox за замовчуванням | Настройки Roblox по умолчанию
Roblox installer started | Інсталятор Roblox запущено | Установщик Roblox запущен
Roblox is starting! 🚀 | Roblox запускається! 🚀 | Roblox запускается! 🚀
Roblox is starting… | Roblox запускається… | Roblox запускается…
Roblox: {ver}     •     {n} FFlags     •     {m} mods | Roblox: {ver}     •     FFlags: {n}     •     модів: {m} | Roblox: {ver}     •     FFlags: {n}     •     модов: {m}
Save a game link — jump in with one click ✦ | Збережи посилання на гру — заходь одним кліком ✦ | Сохрани ссылку на игру — заходи одним кликом ✦
Save password | Зберегти пароль | Сохранить пароль
Saved {n} flags | Збережено флагів: {n} | Сохранено флагов: {n}
Scripts | Скрипти | Скрипты
Search | Пошук | Поиск
Set a password. It will be asked every time you open the Accounts tab. | Встанови пароль. Його питатимуть щоразу, коли відкриваєш вкладку Акаунти. | Установи пароль. Его будут спрашивать каждый раз при открытии вкладки Аккаунты.
Set active | Зробити активним | Сделать активным
Set password  ➜ | Встановити пароль  ➜ | Установить пароль  ➜
Settings | Налаштування | Настройки
Shooting stars | Падаючі зорі | Падающие звёзды
Shortcut “{name}” added | Ярлик «{name}» додано | Ярлык «{name}» добавлен
Shortcuts | Ярлики | Ярлыки
Show chat | Показувати чат | Показывать чат
Show performance stats | Показувати статистику продуктивності | Показывать статистику производительности
Show setup again | Показати підготовку знову | Показать подготовку снова
Show the Scripts tab | Показувати вкладку Скрипти | Показывать вкладку Скрипты
Size | Розмір | Размер
Skip for now | Пропустити | Пропустить
Starfield background | Зоряний фон | Звёздный фон
Start  ➜ | Почати  ➜ | Начать  ➜
Start maximized | Запускати на весь екран | Запускать развёрнутым
Stored encrypted with Windows DPAPI on this PC only. Never share your cookie. | Зберігається зашифрованим (Windows DPAPI) лише на цьому ПК. Нікому не показуй свій cookie. | Хранится зашифрованным (Windows DPAPI) только на этом ПК. Никому не показывай свой cookie.
Target FPS | Цільовий FPS | Целевой FPS
Texture quality | Якість текстур | Качество текстур
Theme, font and language change instantly. | Тема, шрифт і мова змінюються одразу. | Тема, шрифт и язык меняются сразу.
Tweak Roblox itself — applied automatically when you launch | Налаштуй сам Roblox — застосовується автоматично при запуску | Настрой сам Roblox — применяется автоматически при запуске
Unlock | Розблокувати | Разблокировать
Unlock FPS cap | Зняти ліміт FPS | Снять лимит FPS
Unlocked 360 FPS, Direct3D 11, no post-processing or shadows. | 360 FPS без ліміту, Direct3D 11, без постобробки й тіней. | 360 FPS без лимита, Direct3D 11, без постобработки и теней.
Use as Roblox launcher | Використовувати як лаунчер Roblox | Использовать как лаунчер Roblox
Username | Нік | Ник
Username & Password | Нік і пароль | Ник и пароль
Welcome to CloxStraper | Ласкаво просимо до CloxStraper | Добро пожаловать в CloxStraper
Welcome, {name}! ✨ | Вітаємо, {name}! ✨ | Привет, {name}! ✨
Wrong flags can crash Roblox or be silently ignored. Only change what you understand. | Неправильні флаги можуть зламати Roblox або тихо ігноруватися. Змінюй лише те, що розумієш. | Неправильные флаги могут сломать Roblox или молча игнорироваться. Меняй только то, что понимаешь.
Wrong password | Неправильний пароль | Неверный пароль
You can change it later in Settings. | Це можна змінити пізніше в Налаштуваннях. | Это можно изменить позже в Настройках.
You're all set! | Усе готово! | Всё готово!
Your accounts | Твої акаунти | Твои аккаунты
Your image replaces Roblox's arrow cursor (PNG with transparency works best). | Твоє зображення замінює стрілку курсора Roblox (найкраще PNG з прозорістю). | Твоё изображение заменяет стрелку курсора Roblox (лучше всего PNG с прозрачностью).
Your saved preset | Твій збережений пресет | Твой сохранённый пресет
key | ключ | ключ
no font selected | шрифт не обрано | шрифт не выбран
no image | немає зображення | нет изображения
not found | не знайдено | не найден
patched | виправлено | запатчен
verified | перевірено | проверен
“Use as Roblox launcher”: Play buttons on roblox.com start Roblox through CloxStraper (so your FFlags & mods always apply). Roblox updates may undo this. | «Використовувати як лаунчер»: кнопки Play на roblox.com запускають Roblox через CloxStraper (тож твої FFlags і моди завжди застосовуються). Оновлення Roblox можуть це скасувати. | «Использовать как лаунчер»: кнопки Play на roblox.com запускают Roblox через CloxStraper (так твои FFlags и моды всегда применяются). Обновления Roblox могут это отменить.
↺  Reset all | ↺  Скинути все | ↺  Сбросить всё
↺  Restore Roblox defaults | ↺  Відновити стандартний Roblox | ↺  Восстановить стандартный Roblox
▶  Join | ▶  Зайти | ▶  Зайти
● ACTIVE | ● АКТИВНИЙ | ● АКТИВЕН
⚠  WARNING cheats are bad! | ⚠  УВАГА: чити — це погано! | ⚠  ВНИМАНИЕ: читы — это плохо!
⚠  WARNING you can break your game! | ⚠  УВАГА: ти можеш зламати свою гру! | ⚠  ВНИМАНИЕ: ты можешь сломать свою игру!
✓  Apply now | ✓  Застосувати зараз | ✓  Применить сейчас
✦  No shortcuts yet.\\nPaste a game link above to create your first one. | ✦  Ярликів ще немає.\\nВстав посилання на гру вище, щоб створити перший. | ✦  Ярлыков пока нет.\\nВставь ссылку на игру выше, чтобы создать первый.
✨  Animations & sound | ✨  Анімації та звук | ✨  Анимации и звук
⬇  Install Roblox | ⬇  Встановити Roblox | ⬇  Установить Roblox
＋ Add | ＋ Додати | ＋ Добавить
＋ Add shortcut | ＋ Додати ярлик | ＋ Добавить ярлык
🌌  Custom sky | 🌌  Своє небо | 🌌  Своё небо
🎨  Appearance | 🎨  Вигляд | 🎨  Внешний вид
🎮  Graphics | 🎮  Графіка | 🎮  Графика
🎲 Re-roll stars | 🎲 Нові зорі | 🎲 Новые звёзды
👥  Friends in this game | 👥  Друзі в цій грі | 👥  Друзья в этой игре
👥  Friends playing | 👥  Друзі, що грають | 👥  Друзья в игре
💾 Save | 💾 Зберегти | 💾 Сохранить
💾 Save current settings | 💾 Зберегти поточні налаштування | 💾 Сохранить текущие настройки
📁 Open data folder | 📁 Відкрити папку даних | 📁 Открыть папку данных
📋 Paste | 📋 Вставити | 📋 Вставить
🔊  Audio | 🔊  Звук | 🔊  Звук
🔍 Search ScriptBlox… | 🔍 Пошук у ScriptBlox… | 🔍 Поиск в ScriptBlox…
🔍 Search flags… | 🔍 Пошук флагів… | 🔍 Поиск флагов…
🔑 Change password | 🔑 Змінити пароль | 🔑 Сменить пароль
🔤  Custom font | 🔤  Свій шрифт | 🔤  Свой шрифт
🖥  Interface | 🖥  Інтерфейс | 🖥  Интерфейс
🖱  Custom cursor | 🖱  Свій курсор | 🖱  Свой курсор
🖱  Input & Camera | 🖱  Ввід і камера | 🖱  Ввод и камера
🚀  Launcher | 🚀  Лаунчер | 🚀  Лаунчер
Close CloxStraper | Закрити CloxStraper | Закрыть CloxStraper
"""
# fmt: on
TR = {"uk": {}, "ru": {}}
for line in _RAW.strip().splitlines():
    parts = [p.strip() for p in line.split(" | ")]
    if len(parts) == 3:
        en, uk, ru = (p.replace("\\n", "\n") for p in parts)
        TR["uk"][en] = uk; TR["ru"][en] = ru
