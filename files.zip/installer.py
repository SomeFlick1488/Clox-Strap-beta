"""CloxStraper Setup — ставит лаунчер в C:\\Program Files\\CloxStraper. С флагом --uninstall удаляет его."""
import ctypes, math, os, shutil, subprocess, sys, threading, time
import tkinter as tk
import customtkinter as ctk
from PIL import ImageTk
import engine as E
from common import *

ctk.set_appearance_mode("dark")
APP, VERSION = "CloxStraper", E.VERSION
PF = os.environ.get("ProgramFiles", r"C:\Program Files")
INSTALL_DIR = os.path.join(PF, APP)
EXE = os.path.join(INSTALL_DIR, f"{APP}.exe")
UNINS = os.path.join(INSTALL_DIR, "Uninstall.exe")
REG_KEY = r"Software\Microsoft\Windows\CurrentVersion\Uninstall\CloxStraper"
BASE = getattr(sys, "_MEIPASS", os.path.join(os.path.dirname(os.path.abspath(__file__)), "dist"))
NOWIN = 0x08000000


def is_admin():
    try: return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception: return False

def run_ps(script):
    subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script], creationflags=NOWIN, check=False)

def make_shortcuts(desktop, start):
    ps = ["$w=New-Object -ComObject WScript.Shell"]
    for flag, folder in ((desktop, "CommonDesktopDirectory"), (start, "CommonPrograms")):
        if flag:
            ps.append(f'$s=$w.CreateShortcut([IO.Path]::Combine([Environment]::GetFolderPath("{folder}"),"{APP}.lnk"));'
                      f'$s.TargetPath="{EXE}";$s.WorkingDirectory="{INSTALL_DIR}";$s.IconLocation="{EXE}";$s.Save()')
    run_ps(";".join(ps))

def remove_shortcuts():
    run_ps(f'foreach($f in "CommonDesktopDirectory","CommonPrograms"){{Remove-Item ([IO.Path]::Combine([Environment]::GetFolderPath($f),"{APP}.lnk")) -ErrorAction SilentlyContinue}}')

def register_uninstall():
    import winreg
    with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, REG_KEY, 0, winreg.KEY_WRITE | winreg.KEY_WOW64_64KEY) as k:
        for n, v in (("DisplayName", APP), ("DisplayVersion", VERSION), ("Publisher", APP), ("InstallLocation", INSTALL_DIR),
                     ("DisplayIcon", EXE), ("UninstallString", f'"{UNINS}" --uninstall')):
            winreg.SetValueEx(k, n, 0, winreg.REG_SZ, v)
        winreg.SetValueEx(k, "NoModify", 0, winreg.REG_DWORD, 1); winreg.SetValueEx(k, "NoRepair", 0, winreg.REG_DWORD, 1)

def unregister_uninstall():
    import winreg
    try: winreg.DeleteKeyEx(winreg.HKEY_LOCAL_MACHINE, REG_KEY, winreg.KEY_WOW64_64KEY)
    except OSError: pass

def do_install(desktop, start, prog):
    steps = ["Creating folder…", "Copying CloxStraper…", "Creating uninstaller…", "Creating shortcuts…", "Registering in Windows…"]
    subprocess.run(["taskkill", "/f", "/im", f"{APP}.exe"], creationflags=NOWIN, capture_output=True)
    prog(0, steps[0]); os.makedirs(INSTALL_DIR, exist_ok=True); time.sleep(0.4)
    prog(1, steps[1]); src = os.path.join(BASE, f"{APP}.exe")
    if not os.path.exists(src): raise RuntimeError(f"{APP}.exe not found next to the installer")
    shutil.copy2(src, EXE); time.sleep(0.4)
    prog(2, steps[2])
    if getattr(sys, "frozen", False): shutil.copy2(sys.executable, UNINS)
    time.sleep(0.4); prog(3, steps[3]); make_shortcuts(desktop, start); time.sleep(0.3)
    prog(4, steps[4]); register_uninstall(); time.sleep(0.4); prog(5, "Done!")

def do_uninstall(wipe, prog):
    prog(0.1, "Closing CloxStraper…"); subprocess.run(["taskkill", "/f", "/im", f"{APP}.exe"], creationflags=NOWIN, capture_output=True); time.sleep(0.4)
    prog(0.35, "Removing shortcuts…"); remove_shortcuts(); time.sleep(0.3)
    prog(0.55, "Restoring Roblox launcher…")
    try:
        cfg = E.load_cfg(); E.unregister_protocol(cfg)
    except Exception: pass
    prog(0.75, "Cleaning registry…"); unregister_uninstall(); time.sleep(0.3)
    if wipe: shutil.rmtree(E.DATA, ignore_errors=True)
    prog(0.95, "Deleting files…")
    subprocess.Popen(f'cmd /c ping 127.0.0.1 -n 3 >nul & rmdir /s /q "{INSTALL_DIR}"', shell=True, creationflags=NOWIN)
    time.sleep(0.4); prog(1.0, "Done!")


class Setup(ctk.CTk):
    def __init__(self, uninstall=False):
        super().__init__()
        self.mode = "uninstall" if uninstall else "install"
        apply_theme("Crimson")
        self.title(f"{APP} {'Uninstall' if uninstall else 'Setup'}"); self.geometry("780x500"); self.resizable(False, False)
        self.configure(fg_color=C.bg); self.attributes("-alpha", 0.0)
        sc = max(1.0, self.winfo_fpixels("1i") / 96); self.W, self.H = int(780 * sc), int(500 * sc); self.sc = sc
        self.cv = tk.Canvas(self, bg=C.bg, highlightthickness=0, bd=0); self.cv.pack(fill="both", expand=True)
        self.sf = StarField(self.cv, n=130, orbs=True, shoot=True); self.sf.resize(self.W, self.H)
        self.t = 0.0; self.ui_items = []; self.progress = None
        self.ph = ImageTk.PhotoImage(make_planet(int(280 * sc), C.accent, C.accent2))
        self.planet = self.cv.create_image(self.W * 0.24, self.H * 0.5, image=self.ph)
        self.title_t = self.cv.create_text(self.W * 0.64, self.H * 0.2, text="", fill=C.text, font=F(28, True))
        self.sub_t = self.cv.create_text(self.W * 0.64, self.H * 0.29, text="", fill=C.muted, font=F(12), width=int(self.W * 0.45))
        self.fade(); self.tick()
        (self.uninstall_screen if uninstall else self.welcome)()

    def fade(self, a=0.0):
        a += 0.05; self.attributes("-alpha", min(a, 1))
        if a < 1: self.after(16, lambda: self.fade(a))

    def tick(self):
        self.t += 0.033
        try:
            self.sf.step(0.033); self.cv.coords(self.planet, self.W * 0.24, self.H * 0.5 + 9 * math.sin(self.t * 1.3))
        except tk.TclError: return
        self.after(33, self.tick)

    def type_text(self, item, text, delay=28, i=0):
        try:
            self.cv.itemconfigure(item, text=text[:i])
            if i < len(text): self.after(delay, lambda: self.type_text(item, text, delay, i + 1))
        except tk.TclError: pass

    def clear(self):
        for it in self.ui_items: self.cv.delete(it[0]); it[1].destroy()
        self.ui_items = []

    def put(self, widget, y, delay=0):
        x = self.W * 0.64; it = self.cv.create_window(self.W + 300, y, window=widget); self.ui_items.append((it, widget))
        def go(): tween(self, 600, lambda e: self.cv.coords(it, lerp(self.W + 300, x, e), y))
        self.after(delay, go); return widget

    def btn(self, text, cmd, primary=True, w=200):
        return ctk.CTkButton(self.cv, text=text, command=cmd, width=w, height=46, corner_radius=23, font=F(15, True), bg_color=C.bg,
                             fg_color=C.accent if primary else C.card2, hover_color=C.accent2 if primary else C.card)

    def check(self, text, value=True):
        v = tk.BooleanVar(value=value)
        c = ctk.CTkCheckBox(self.cv, text=text, variable=v, font=F(13), text_color=C.text, fg_color=C.accent, hover_color=C.accent2, bg_color=C.bg)
        c.var = v; return c

    # ------------------------------------------------ install
    def welcome(self):
        self.clear(); self.type_text(self.title_t, f"{APP} Setup"); self.type_text(self.sub_t, "A cosmic Roblox launcher — FFlags, mods, accounts and shortcuts.")
        H = self.H
        lbl = ctk.CTkLabel(self.cv, text=f"Install to:\n{INSTALL_DIR}", font=F(12), text_color=C.accent2, bg_color=C.bg, justify="left")
        self.put(lbl, H * 0.43, 100)
        self.c_desk = self.put(self.check("Desktop shortcut"), H * 0.55, 200); self.c_start = self.put(self.check("Start Menu shortcut"), H * 0.61, 280)
        self.c_run = self.put(self.check("Launch CloxStraper when finished"), H * 0.67, 360)
        row = ctk.CTkFrame(self.cv, fg_color="transparent", bg_color=C.bg)
        b1 = self.btn("Install  ➜", self.start_install, True, 170); b2 = self.btn("Cancel", self.destroy, False, 120)
        b1.pack(in_=row, side="left"); b2.pack(in_=row, side="left", padx=10)
        self.put(row, H * 0.82, 460)

    def start_install(self):
        opts = (self.c_desk.var.get(), self.c_start.var.get(), self.c_run.var.get())
        if not is_admin():
            self.cv.itemconfigure(self.sub_t, text="Administrator rights are required — please run the installer as administrator.", fill=RED); return
        self.clear(); self.cv.itemconfigure(self.title_t, text="Installing…"); self.cv.itemconfigure(self.sub_t, text="", fill=C.muted)
        bar = ctk.CTkProgressBar(self.cv, width=330, height=14, corner_radius=8, progress_color=C.accent2, fg_color=C.card2, bg_color=C.bg); bar.set(0)
        self.step_lbl = ctk.CTkLabel(self.cv, text="Starting…", font=F(13), text_color=C.muted, bg_color=C.bg)
        self.put(bar, self.H * 0.5); self.put(self.step_lbl, self.H * 0.57, 80); self.bar = bar
        def prog(i, text):
            def ui():
                self.step_lbl.configure(text=text); self.smooth(i / 5)
            self.after(0, ui)
        def work():
            try:
                do_install(opts[0], opts[1], prog); self.after(0, lambda: self.after(700, lambda: self.finished(opts[2])))
            except Exception as e:
                msg = str(e); self.after(0, lambda: (self.cv.itemconfigure(self.sub_t, text=f"Error: {msg}", fill=RED), self.step_lbl.configure(text="Failed")))
        threading.Thread(target=work, daemon=True).start()

    def smooth(self, target):
        try:
            cur = self.bar.get()
            if abs(target - cur) > 0.003: self.bar.set(cur + (target - cur) * 0.2); self.after(16, lambda: self.smooth(target))
            else: self.bar.set(target)
        except tk.TclError: pass

    def finished(self, run):
        self.clear(); self.type_text(self.title_t, "All set! ✨"); self.type_text(self.sub_t, f"{APP} was installed to {INSTALL_DIR}")
        def fin():
            if run: subprocess.Popen([EXE], cwd=INSTALL_DIR, creationflags=0x00000008)
            self.destroy()
        self.put(self.btn("Finish", fin, True, 200), self.H * 0.55, 150)

    # ------------------------------------------------ uninstall
    def uninstall_screen(self):
        self.clear(); self.type_text(self.title_t, f"Uninstall {APP}?"); self.type_text(self.sub_t, "This removes the launcher, its shortcuts and registry entries.")
        self.c_wipe = self.put(self.check("Also delete my accounts & settings", False), self.H * 0.5, 120)
        row = ctk.CTkFrame(self.cv, fg_color="transparent", bg_color=C.bg)
        self.btn("Uninstall", self.start_uninstall, True, 160).pack(in_=row, side="left"); self.btn("Cancel", self.destroy, False, 120).pack(in_=row, side="left", padx=10)
        self.put(row, self.H * 0.64, 220)

    def start_uninstall(self):
        wipe = self.c_wipe.var.get(); self.clear(); self.cv.itemconfigure(self.title_t, text="Uninstalling…"); self.cv.itemconfigure(self.sub_t, text="")
        self.bar = ctk.CTkProgressBar(self.cv, width=330, height=14, corner_radius=8, progress_color=C.accent2, fg_color=C.card2, bg_color=C.bg); self.bar.set(0)
        self.step_lbl = ctk.CTkLabel(self.cv, text="", font=F(13), text_color=C.muted, bg_color=C.bg)
        self.put(self.bar, self.H * 0.5); self.put(self.step_lbl, self.H * 0.57, 80)
        def prog(p, text): self.after(0, lambda: (self.step_lbl.configure(text=text), self.smooth(p)))
        def work():
            try: do_uninstall(wipe, prog)
            except Exception as e: prog(0, f"Error: {e}"); return
            self.after(800, lambda: (self.clear(), self.type_text(self.title_t, "Uninstalled"), self.type_text(self.sub_t, "See you among the stars 🌌"),
                                     self.put(self.btn("Close", self.destroy, True, 160), self.H * 0.55, 150)))
        threading.Thread(target=work, daemon=True).start()


def main():
    if os.name == "nt" and not is_admin():
        params = " ".join(f'"{a}"' for a in (sys.argv if getattr(sys, "frozen", False) else sys.argv))
        exe = sys.executable; args = " ".join(f'"{a}"' for a in sys.argv[1:]) if getattr(sys, "frozen", False) else params
        try:
            ctypes.windll.shell32.ShellExecuteW(None, "runas", exe, args, None, 1); return
        except Exception: pass
    Setup("--uninstall" in sys.argv).mainloop()


if __name__ == "__main__":
    main()
