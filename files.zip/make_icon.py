from PIL import Image, ImageDraw
from common import make_planet, apply_theme, C, hex2rgb
apply_theme("Crimson")
S = 256
bg = Image.new("RGBA", (S, S), (0, 0, 0, 0))
ImageDraw.Draw(bg).rounded_rectangle((0, 0, S - 1, S - 1), radius=56, fill=hex2rgb(C.bg) + (255,))
bg.alpha_composite(make_planet(S, C.accent, C.accent2))
bg.save("icon.ico", sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
print("icon.ico готов")
