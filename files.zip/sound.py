"""Звуки интерфейса: генерируются в памяти, играются через winsound (только Windows)."""
import io, math, struct, wave
try: import winsound
except ImportError: winsound = None

SOUND = {"on": True}
_cache = {}
_DEF = {"click": ([1200, 1800], 45, 0.28, 9, 0.0), "ok": ([660, 990, 1320], 170, 0.25, 5, 0.1), "err": ([200, 150], 230, 0.3, 5, -0.2),
        "whoosh": ([300, 450], 140, 0.18, 6, 0.8), "pop": ([700], 60, 0.25, 8, 0.5)}

def _tone(freqs, ms, vol, decay, glide):
    rate = 22050; n = int(rate * ms / 1000); buf = io.BytesIO(); fr = bytearray()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate)
        for i in range(n):
            t = i / rate; p = i / n; env = math.exp(-decay * p) * min(1, i / 80)
            s = sum(math.sin(2 * math.pi * f * (1 + glide * p) * t) for f in freqs) / len(freqs)
            fr += struct.pack("<h", int(max(-1, min(1, s * env * vol)) * 32767))
        w.writeframes(bytes(fr))
    return buf.getvalue()

def play(name):
    if not SOUND["on"] or winsound is None: return
    try:
        if name not in _cache: _cache[name] = _tone(*_DEF[name])
        winsound.PlaySound(_cache[name], winsound.SND_MEMORY | winsound.SND_ASYNC)
    except Exception: pass
